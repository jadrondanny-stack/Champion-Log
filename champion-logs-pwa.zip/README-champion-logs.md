# Champion Logs

Unofficial Raid: Shadow Legends barracks + team helper.

## Use on your phone
1. Open `champion-logs.html` in Safari or Chrome.
2. iPhone: Share → Add to Home Screen.
3. Android Chrome: menu → Add to Home Screen / Install app.

Works as a file. Install/offline works best after you host it.

## Publish a public link (GitHub Pages)
1. Create a GitHub repo.
2. Upload `champion-logs.html`, `manifest.webmanifest`, and `sw.js`.
3. Settings → Pages → Deploy from branch `main` / root.
4. Open `https://YOURUSER.github.io/REPO/champion-logs.html`.

Netlify / Cloudflare Pages: drag the three files into a new site.

## What I cannot do from this chat
Apple App Store, Google Play, and TestFlight all need *your* developer account, signing certificates, and store listing. This PWA is the version you can actually ship today.

## CSV
Barracks → Export CSV / Import CSV. Columns:
`name,owned,stars,skills,soul,bless,set1,set2`
