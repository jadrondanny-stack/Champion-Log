self.addEventListener("install", event => {
  event.waitUntil(caches.open("cl-v2").then(c => c.addAll([
    "./champion-logs.html",
    "./manifest.webmanifest"
  ])));
  self.skipWaiting();
});
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(hit => hit || fetch(event.request).then(res => {
      const copy = res.clone();
      caches.open("cl-v2").then(c => c.put(event.request, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match("./champion-logs.html")))
  );
});
