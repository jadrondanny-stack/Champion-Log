//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-AsOyIF7R.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BrWD6bKw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BrWD6bKw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CaJUOI_p.js"]
	}
} });
//#endregion
export { tsrStartManifest };
