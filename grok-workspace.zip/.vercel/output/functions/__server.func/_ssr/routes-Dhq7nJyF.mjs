import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Swords, c as Search, d as KeyRound, f as Flame, i as Trash2, l as Plus, n as Waves, o as Skull, s as Shield, t as X, u as ListOrdered } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dhq7nJyF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ACC = "Debuffers want about 250 accuracy on Demon Lord Ultra-Nightmare (220 on Nightmare, 200 on Brutal). Hydra Nightmare is closer to 350. On Chimera, sit about 25 accuracy over that difficulty's resistance.";
var BRIM = "Put 5 or 6 star Brimstone on one champion only. A second debuffer should take Cruelty instead. Two Brimstones do not stack.";
function gear(partial) {
	return {
		acc: ACC,
		blessing: BRIM,
		...partial
	};
}
var GEAR = {
	debuffer: gear({
		sets: "Speed plus Perception until accuracy is capped, then Relentless if you can afford the stats.",
		stats: "Boots Speed. Chest and gloves HP% or DEF%. Banner Accuracy. Crit rate is optional.",
		masteries: "Sniper and Master Hexer from Support. Warmaster from Offense. Defense tree so they live the stun."
	}),
	poison: gear({
		sets: "Lifesteal plus Speed when the team has no Leech. Otherwise Speed, Perception, or Relentless.",
		stats: "Boots Speed. Chest and gloves HP% or DEF%. Enough HP and DEF to take the stun. Accuracy before crit.",
		masteries: "Warmaster. Use Giant Slayer only if they hit three or more times on most turns."
	}),
	burn: gear({
		sets: "Speed and Perception, or Relentless. Accuracy and uptime beat raw attack.",
		stats: "Boots Speed. Chest and gloves HP% or DEF% unless they are also your nuker. One reliable burn is enough on Demon Lord — a second burn does not stack on the same target. On Hydra, extra burners still help because each head is its own target.",
		masteries: "Warmaster, Sniper, Master Hexer."
	}),
	nuker: gear({
		sets: "Savage or Lethal. Merciless or Cruel if that is the pair you can finish. Ignore defense is the multiplier.",
		stats: "100% crit rate, then crit damage. Boots Speed unless a tune says otherwise. Chest ATK% on attack champions. Banner Accuracy only if they must land a debuff.",
		masteries: "Helmsmasher if you are not already in an ignore-defense set, otherwise Flawless Execution. Warmaster or Giant Slayer by how many hits they throw.",
		blessing: "Crushing Rend on the main nuker. Leave Brimstone on a support so the nuker can take the damage blessing."
	}),
	nukerDef: gear({
		sets: "Savage or Lethal, with Perception mixed in if accuracy is short. Relentless is a proven alternative on Gnut.",
		stats: "100% crit rate, high crit damage, and DEF% on chest and gloves — the hit scales off defense. Boots Speed. Accuracy high enough to land Decrease DEF and Weaken.",
		masteries: "Warmaster or Giant Slayer to match the hit count. Helmsmasher if the sets are not already ignoring defense.",
		blessing: "Crushing Rend. He does not need Brimstone if anyone else carries it."
	}),
	protector: gear({
		sets: "Guardian or Bolster on the ally-protect champion. Speed, Immortal, or Regeneration if you cannot finish a Guardian set.",
		stats: "This champion eats damage for two people. Stack DEF and HP. Boots Speed, matched to the tune so the protect is up before the boss AoE.",
		masteries: "Defense tree, Warmaster, and the mastery that boosts ally protection if you have it. Survival over damage."
	}),
	support: gear({
		sets: "Speed plus Immortal, Regeneration, or Perception. Relentless on champions whose best skill has a long cooldown.",
		stats: "Boots Speed — supports usually move first. Chest and gloves HP% or DEF%. Resist is a luxury until speed and accuracy are done.",
		masteries: "Support tree: Sniper, Master Hexer, and the healing or turn-meter masteries that match the kit. Warmaster if they still hit the boss."
	}),
	unkillable: gear({
		sets: "Three Speed sets is the usual answer. The set bonuses are only there to hit a speed number.",
		stats: "Exact speed matters more than any other stat. A classic Maneater and Painkeeper tune is Maneater at 254, Painkeeper at 240, damage dealers at 177–179, and the slow stun target at 121–128. Write the speeds down before you regear. Missing by 2 ruins the comp.",
		acc: "The unkillable champion often needs little accuracy. Debuffers inside the same tune still need 250 on Ultra-Nightmare.",
		masteries: "Take speed masteries. Skip anything that boosts turn meter unless that exact tune calls for it — a surprise turn meter fill desyncs the comp.",
		blessing: "Phantom Touch or Brimstone on the damage dealers. The unkillable champions themselves can hold Cruelty."
	}),
	shield: gear({
		sets: "Speed plus Immortal, or Bolster if the shield needs to start bigger. Do not dump all your speed to chase a shield set.",
		stats: "Wixwell-style comps want him among the fastest so Increase DEF and Shield are up, then the shield value grows. Chest DEF% or HP%. Accuracy if they also provoke.",
		masteries: "Support and Defense. Lore of Steel if Speed or Perception is equipped. Lasting Gifts helps the buffs stick.",
		blessing: "Cruelty on the buffer. The damage dealer beside them takes Crushing Rend or Brimstone, not both."
	})
};
var G = GEAR;
function c(champ) {
	return champ;
}
var CHAMPIONS = [
	c({
		id: "gnut",
		name: "Gnut",
		faction: "Dwarves",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 99,
			hydra: 90,
			chimera: 94
		},
		tags: [
			"enemy-max-hp",
			"dec-def",
			"dec-atk",
			"weaken",
			"counter"
		],
		gear: G.nukerDef,
		blurb: "Defense-based max-HP hits plus Decrease ATK, Weaken, and Decrease DEF. A top damage dealer on all three bosses.",
		aliases: ["gnut"]
	}),
	c({
		id: "dracomorph",
		name: "Dracomorph",
		faction: "Lizardmen",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 96,
			hydra: 82,
			chimera: 88
		},
		tags: [
			"poison",
			"hp-burn",
			"dec-def",
			"weaken",
			"dec-atk"
		],
		gear: G.debuffer,
		blurb: "The classic one-champion debuff kit: poisons, HP Burn, Decrease DEF, Weaken, and Decrease ATK.",
		aliases: ["draco"]
	}),
	c({
		id: "geomancer",
		name: "Geomancer",
		faction: "Dwarves",
		affinity: "Force",
		rarity: "Epic",
		role: "Attack",
		aura: "Increases ally HP in all battles by 25%.",
		scores: {
			demon: 98,
			hydra: 74,
			chimera: 84
		},
		tags: [
			"hp-burn",
			"weaken",
			"dec-acc",
			"reflect",
			"hp-aura"
		],
		gear: {
			...G.debuffer,
			sets: "Perception plus Speed, or Reflex so the burn and Weaken come back faster. He is not a Savage nuker.",
			stats: "His damage is the passive reflect while HP Burn is up, not his attack stat. Boots Speed, chest and gloves HP% or DEF%, banner Accuracy. Surviving the stun is the whole build."
		},
		blurb: "HP Burn and Weaken, then his passive throws a chunk of the boss hit back. One of the best epics ever printed for Demon Lord.",
		aliases: ["geo"]
	}),
	c({
		id: "wixwell",
		name: "Vault Keeper Wixwell",
		faction: "Sacred Order",
		affinity: "Force",
		rarity: "Legendary",
		role: "Defense",
		aura: "Increases ally DEF in all battles by 28%.",
		scores: {
			demon: 97,
			hydra: 86,
			chimera: 95
		},
		tags: [
			"shield",
			"shield-grow",
			"inc-def",
			"provoke",
			"counter",
			"intercept",
			"def-aura"
		],
		gear: G.shield,
		blurb: "Grows shield value every turn and provokes. The engine of the shield comp on Demon Lord and Chimera, and a Mischief provoker on Hydra.",
		aliases: ["wixwell", "vault keeper"]
	}),
	c({
		id: "brogni",
		name: "Underpriest Brogni",
		faction: "Dwarves",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 93,
			hydra: 84,
			chimera: 92
		},
		tags: [
			"shield",
			"hp-burn",
			"reflect",
			"strengthen"
		],
		gear: G.shield,
		blurb: "Team shields that reflect, plus HP Burn. The partner Wixwell wants beside him.",
		aliases: ["brogni"]
	}),
	c({
		id: "acrizia",
		name: "Acrizia",
		faction: "Dwarves",
		affinity: "Void",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 97,
			hydra: 92,
			chimera: 95
		},
		tags: ["enemy-max-hp"],
		gear: G.nuker,
		blurb: "Void enemy-max-HP damage with no weak hits. She is a cannon, not a debuffer — pair her with Decrease DEF and Weaken.",
		aliases: ["acrizia"]
	}),
	c({
		id: "ninja",
		name: "Ninja",
		faction: "Shadowkin",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 95,
			hydra: 80,
			chimera: 86
		},
		tags: ["hp-burn", "boss-dmg"],
		gear: {
			...G.nuker,
			acc: "He must land HP Burn. " + G.nuker.acc
		},
		blurb: "HP Burn plus extra damage into bosses. Excellent in ally-attack teams because the burn stays while everyone else hits.",
		aliases: ["ninja"]
	}),
	c({
		id: "lydia",
		name: "Lydia the Deathsiren",
		faction: "Dark Elves",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 90,
			hydra: 91,
			chimera: 90
		},
		tags: [
			"weaken",
			"dec-def",
			"strengthen"
		],
		gear: G.support,
		blurb: "Void Decrease DEF, Weaken, and team Strengthen. A free account's best all-round boss support once Doom Tower is done.",
		aliases: ["lydia"]
	}),
	c({
		id: "mithrala",
		name: "Mithrala",
		faction: "Dark Elves",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 62,
			hydra: 98,
			chimera: 84
		},
		tags: [
			"hex",
			"shield",
			"strengthen",
			"cleanse",
			"inc-spd"
		],
		gear: G.support,
		blurb: "The Hydra fragment legendary. Hex, shields, cleanse, and speed — built for heads, still useful on Chimera.",
		aliases: ["mithrala", "mythrala"]
	}),
	c({
		id: "krisk",
		name: "Krisk the Ageless",
		faction: "Lizardmen",
		affinity: "Void",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 84,
			hydra: 95,
			chimera: 94
		},
		tags: [
			"shield",
			"dec-atk",
			"dec-spd",
			"inc-def",
			"ally-protect"
		],
		gear: G.protector,
		blurb: "Void shields, Decrease ATK, Decrease SPD, and Increase DEF, with ally protection while the shield holds.",
		aliases: ["krisk"]
	}),
	c({
		id: "pythion",
		name: "Pythion",
		faction: "Lizardmen",
		affinity: "Force",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 72,
			hydra: 93,
			chimera: 97
		},
		tags: [
			"cleanse",
			"heal",
			"block-debuffs",
			"revive",
			"strengthen"
		],
		gear: G.support,
		blurb: "Full cleanse, Block Debuffs, a heal, and a team revive. Chimera and Hydra both punish teams that cannot cleanse.",
		aliases: ["pythion"]
	}),
	c({
		id: "elva",
		name: "Elva Autumnborn",
		faction: "Sylvan Watchers",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 64,
			hydra: 90,
			chimera: 95
		},
		tags: [
			"cleanse",
			"heal",
			"revive",
			"block-debuffs",
			"inc-spd"
		],
		gear: G.support,
		blurb: "Cleanse, Block Debuffs, Increase SPD, and a revive. A Chimera anchor when Pythion is not in the vault.",
		aliases: ["elva"]
	}),
	c({
		id: "nekmo",
		name: "Nekmo Thaar",
		faction: "Lizardmen",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 70,
			hydra: 96,
			chimera: 82
		},
		tags: [
			"leech",
			"dec-spd",
			"inc-spd",
			"hex",
			"tm-boost"
		],
		gear: G.support,
		blurb: "Leech, Hex, Decrease SPD, and a turn-meter boost. One of the safest Hydra speed leads.",
		aliases: ["nekmo"]
	}),
	c({
		id: "mikage",
		name: "Lady Mikage",
		faction: "Shadowkin",
		affinity: "Force",
		rarity: "Mythical",
		role: "Support",
		scores: {
			demon: 90,
			hydra: 88,
			chimera: 89
		},
		tags: [
			"ally-attack",
			"inc-atk",
			"inc-crit",
			"dec-def",
			"tm-boost"
		],
		gear: G.support,
		blurb: "Ally attack plus buffs and Decrease DEF. She multiplies whatever damage dealers you already built.",
		aliases: ["mikage", "lady mikage"]
	}),
	c({
		id: "venus",
		name: "Venus",
		faction: "Sacred Order",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 90,
			hydra: 93,
			chimera: 88
		},
		tags: [
			"poison",
			"dec-def",
			"weaken",
			"aoe"
		],
		gear: G.debuffer,
		blurb: "AoE poisons with Decrease DEF and Weaken. Void, so she never weak-hits a rotating affinity.",
		aliases: ["venus"]
	}),
	c({
		id: "vizier",
		name: "Vizier Ovelis",
		faction: "Dark Elves",
		affinity: "Force",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 94,
			hydra: 48,
			chimera: 44
		},
		tags: ["extend-debuff"],
		gear: {
			...G.debuffer,
			stats: "As much speed as the tune allows so he keeps extending. He does almost no damage himself. Accuracy is optional — the extend is a passive on his hits."
		},
		blurb: "Extends debuffs on every hit. Absurd on Demon Lord once the debuffs are landed, and quiet everywhere else.",
		aliases: ["vizier"]
	}),
	c({
		id: "bek",
		name: "Bad-el-Kazar",
		faction: "Undead Hordes",
		affinity: "Force",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 93,
			hydra: 86,
			chimera: 90
		},
		tags: [
			"poison",
			"cleanse",
			"heal"
		],
		gear: G.support,
		blurb: "Poisons, a real heal, and a cleanse on the passive. The legendary version of the budget cleanser-poisoner.",
		aliases: [
			"bad el",
			"bad-el",
			"bek",
			"bad el kazar"
		]
	}),
	c({
		id: "helicath",
		name: "Helicath",
		faction: "Demonspawn",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 96,
			hydra: 50,
			chimera: 42
		},
		tags: ["block-damage", "dec-spd"],
		gear: G.unkillable,
		blurb: "Block Damage on a short cooldown. A Demon Lord cheat code. Lion form on Chimera ignores it, so do not build Chimera around him.",
		aliases: ["helicath"]
	}),
	c({
		id: "emic",
		name: "Emic Trunkheart",
		faction: "Sylvan Watchers",
		affinity: "Void",
		rarity: "Legendary",
		role: "HP",
		scores: {
			demon: 94,
			hydra: 64,
			chimera: 58
		},
		tags: [
			"block-damage",
			"ally-protect",
			"shield",
			"leech"
		],
		gear: G.unkillable,
		blurb: "Block Damage, shields, Leech, and ally protect. A full Demon Lord survival kit in one champion.",
		aliases: ["emic"]
	}),
	c({
		id: "artak",
		name: "Artak",
		faction: "Orcs",
		affinity: "Magic",
		rarity: "Legendary",
		role: "HP",
		scores: {
			demon: 70,
			hydra: 94,
			chimera: 74
		},
		tags: ["hp-burn", "aoe"],
		gear: G.burn,
		blurb: "AoE HP Burn that he can activate. Built to set several Hydra heads on fire in one rotation.",
		aliases: ["artak"]
	}),
	c({
		id: "michinaki",
		name: "Michinaki",
		faction: "Shadowkin",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 76,
			hydra: 95,
			chimera: 78
		},
		tags: [
			"hp-burn",
			"hex",
			"dec-def",
			"aoe"
		],
		gear: G.burn,
		blurb: "HP Burn, Hex, and Decrease DEF in an AoE kit. A Hydra damage piece that still debuffs.",
		aliases: ["michinaki"]
	}),
	c({
		id: "rathalos",
		name: "Rathalos Blademaster",
		faction: "Barbarians",
		affinity: "Force",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 91,
			hydra: 78,
			chimera: 86
		},
		tags: [
			"hp-burn",
			"boss-dmg",
			"inc-atk"
		],
		gear: G.nuker,
		blurb: "HP Burn and a heavy bonus into bosses, plus Increase ATK for the team.",
		aliases: ["rathalos"]
	}),
	c({
		id: "tatura",
		name: "Tatura Rimehide",
		faction: "High Elves",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 76,
			hydra: 84,
			chimera: 90
		},
		tags: [
			"block-debuffs",
			"ally-protect",
			"shield",
			"inc-def"
		],
		gear: G.protector,
		blurb: "Block Debuffs, ally protect, and shields. Chimera's Viper form and Hydra's poison cloud both hate him.",
		aliases: ["tatura"]
	}),
	c({
		id: "kyoku",
		name: "Kyoku",
		faction: "Shadowkin",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 82,
			hydra: 74,
			chimera: 80
		},
		tags: [
			"ally-protect",
			"strengthen",
			"counter",
			"dec-atk"
		],
		gear: G.protector,
		blurb: "Ally protect, Strengthen, a counter, and Decrease ATK. A modern Martyr for teams that still take the hit.",
		aliases: ["kyoku"]
	}),
	c({
		id: "valkyrie",
		name: "Valkyrie",
		faction: "Barbarians",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 92,
			hydra: 52,
			chimera: 80
		},
		tags: [
			"counter",
			"shield",
			"strengthen"
		],
		gear: G.shield,
		blurb: "Counterattack plus a growing shield. Famous on Demon Lord. Risky on Hydra because Mischief steals the buffs she lives on.",
		aliases: ["valk", "valkyrie"]
	}),
	c({
		id: "martyr",
		name: "Martyr",
		faction: "Sacred Order",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 90,
			hydra: 66,
			chimera: 68
		},
		tags: ["counter", "dec-def"],
		gear: G.protector,
		blurb: "Team counterattack and Decrease DEF. A whole extra round of Warmaster procs on Demon Lord.",
		aliases: ["martyr"]
	}),
	c({
		id: "iron-brago",
		name: "Iron Brago",
		faction: "Orcs",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Defense",
		aura: "Increases ally DEF in all battles.",
		scores: {
			demon: 78,
			hydra: 64,
			chimera: 72
		},
		tags: [
			"inc-def",
			"dec-def",
			"def-aura"
		],
		gear: G.support,
		blurb: "Increase DEF for the team and Decrease DEF on the boss, with a defense aura.",
		aliases: ["brago", "iron brago"]
	}),
	c({
		id: "cardiel",
		name: "Cardiel",
		faction: "Sacred Order",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 74,
			hydra: 82,
			chimera: 80
		},
		tags: [
			"tm-boost",
			"ally-attack",
			"cleanse",
			"inc-atk"
		],
		gear: G.support,
		blurb: "Turn meter, ally attack, cleanse, and Increase ATK. Void, so he fits any affinity week.",
		aliases: ["cardiel"]
	}),
	c({
		id: "duchess",
		name: "Duchess Lilitu",
		faction: "Demonspawn",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 42,
			hydra: 58,
			chimera: 64
		},
		tags: [
			"veil",
			"block-debuffs",
			"revive",
			"inc-def",
			"strengthen"
		],
		gear: G.support,
		blurb: "Incredible in arena, merely fine on bosses. Veil can complicate Hydra, and she brings no damage debuffs.",
		aliases: ["duchess", "lilitu"]
	}),
	c({
		id: "arbiter",
		name: "Arbiter",
		faction: "High Elves",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		aura: "Increases ally SPD in all battles by 30%.",
		scores: {
			demon: 36,
			hydra: 72,
			chimera: 70
		},
		tags: [
			"tm-boost",
			"inc-atk",
			"revive",
			"speed-aura"
		],
		gear: G.support,
		blurb: "The best speed aura in the game, and a revive. Her full-team turn meter boost breaks Demon Lord speed tunes. Use her on Hydra or Chimera, not inside an unkillable tune.",
		aliases: ["arbiter"]
	}),
	c({
		id: "mashalled",
		name: "Ma'Shalled",
		faction: "Undead Hordes",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 58,
			hydra: 76,
			chimera: 64
		},
		tags: ["leech", "inc-spd"],
		gear: G.debuffer,
		blurb: "Leech and Increase SPD. He keeps a Hydra team healed through their own damage.",
		aliases: ["mashalled", "ma shalled"]
	}),
	c({
		id: "wythir",
		name: "Wythir the Crowned",
		faction: "Demonspawn",
		affinity: "Force",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 68,
			hydra: 80,
			chimera: 88
		},
		tags: [
			"heal",
			"cont-heal",
			"cleanse",
			"shield"
		],
		gear: G.support,
		blurb: "Continuous heals, a cleanse, and shields. A comfort pick for 65-turn Chimera fights.",
		aliases: ["wythir"]
	}),
	c({
		id: "oella",
		name: "Oella",
		faction: "Sylvan Watchers",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 60,
			hydra: 82,
			chimera: 84
		},
		tags: [
			"heal",
			"inc-spd",
			"cleanse",
			"tm-boost"
		],
		gear: G.support,
		blurb: "Heal, cleanse, Increase SPD, and turn meter. A modern Apothecary with legendary numbers.",
		aliases: ["oella"]
	}),
	c({
		id: "tramaria",
		name: "Tramaria",
		faction: "Dark Elves",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 48,
			hydra: 90,
			chimera: 70
		},
		tags: [
			"block-buffs",
			"perfect-veil",
			"inc-spd"
		],
		gear: G.support,
		blurb: "Block Buffs on a Void legendary. She shuts off Hydra's Head of Suffering cleanse.",
		aliases: ["tramaria"]
	}),
	c({
		id: "riho",
		name: "Riho Bonespear",
		faction: "Shadowkin",
		affinity: "Void",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 55,
			hydra: 80,
			chimera: 84
		},
		tags: [
			"cleanse",
			"block-debuffs",
			"heal"
		],
		gear: G.support,
		blurb: "Cleanse and Block Debuffs with no affinity problem. A Void answer to Viper poisons and Hydra clouds.",
		aliases: ["riho"]
	}),
	c({
		id: "sicia",
		name: "Sicia Flametongue",
		faction: "Demonspawn",
		affinity: "Force",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 68,
			hydra: 88,
			chimera: 70
		},
		tags: ["hp-burn", "aoe"],
		gear: G.burn,
		blurb: "AoE HP Burn for Hydra heads. On Demon Lord a second burner is mostly wasted, so she is the burner, not an extra one.",
		aliases: ["sicia"]
	}),
	c({
		id: "tyrant",
		name: "Tyrant Ixlimor",
		faction: "Demonspawn",
		affinity: "Magic",
		rarity: "Legendary",
		role: "HP",
		scores: {
			demon: 80,
			hydra: 76,
			chimera: 72
		},
		tags: [
			"hp-burn",
			"dec-atk",
			"shield"
		],
		gear: G.burn,
		blurb: "HP Burn, Decrease ATK, and shields. An older legendary that still covers three boss jobs.",
		aliases: ["tyrant", "ixlimor"]
	}),
	c({
		id: "supreme-galek",
		name: "Supreme Galek",
		faction: "Orcs",
		affinity: "Void",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 74,
			hydra: 78,
			chimera: 66
		},
		tags: ["hp-burn", "extend-debuff"],
		gear: G.burn,
		blurb: "Extends HP Burn. Pair him with one other burner and the debuff never falls off.",
		aliases: ["galek", "supreme galek"]
	}),
	c({
		id: "kalvalax",
		name: "Kalvalax",
		faction: "Knight Revenant",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 84,
			hydra: 55,
			chimera: 60
		},
		tags: ["poison"],
		gear: G.poison,
		blurb: "A poison machine for Demon Lord. He does not bring Decrease DEF, so someone else must.",
		aliases: ["kalvalax"]
	}),
	c({
		id: "teumesia",
		name: "Teumesia",
		faction: "Skinwalkers",
		affinity: "Void",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 66,
			hydra: 80,
			chimera: 64
		},
		tags: ["hp-burn"],
		gear: G.burn,
		blurb: "Activates and places HP Burn. Best as the second Hydra burner next to Artak or Ninja.",
		aliases: ["teumesia"]
	}),
	c({
		id: "tomb-lord",
		name: "Tomb Lord",
		faction: "Knight Revenant",
		affinity: "Spirit",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 76,
			hydra: 72,
			chimera: 70
		},
		tags: [
			"poison",
			"dec-def",
			"dec-atk"
		],
		gear: G.debuffer,
		blurb: "Poisons with Decrease DEF and Decrease ATK. A compact Demon Lord debuffer when Draco is missing.",
		aliases: ["tomb lord"]
	}),
	c({
		id: "narma",
		name: "Narma the Returned",
		faction: "Knight Revenant",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Support",
		scores: {
			demon: 72,
			hydra: 86,
			chimera: 74
		},
		tags: [
			"leech",
			"hex",
			"dec-def"
		],
		gear: G.debuffer,
		blurb: "Leech, Hex, and Decrease DEF. Hydra likes every piece of that.",
		aliases: ["narma"]
	}),
	c({
		id: "roshcard",
		name: "Roshcard the Tower",
		faction: "Sacred Order",
		affinity: "Magic",
		rarity: "Legendary",
		role: "HP",
		scores: {
			demon: 90,
			hydra: 40,
			chimera: 44
		},
		tags: ["block-damage", "shield"],
		gear: G.unkillable,
		blurb: "Block Damage for Demon Lord unkillable-style tunes. Chimera's Lion form ignores the buff.",
		aliases: ["roshcard", "tower"]
	}),
	c({
		id: "sir-nicholas",
		name: "Sir Nicholas",
		faction: "Sacred Order",
		affinity: "Void",
		rarity: "Legendary",
		role: "HP",
		scores: {
			demon: 82,
			hydra: 36,
			chimera: 40
		},
		tags: ["unkillable", "shield"],
		gear: G.unkillable,
		blurb: "Unkillable and a shield. A Demon Lord specialist with little to say on the other two bosses.",
		aliases: ["santa", "sir nicholas"]
	}),
	c({
		id: "visix",
		name: "Visix the Unbowed",
		faction: "Dark Elves",
		affinity: "Void",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 44,
			hydra: 88,
			chimera: 60
		},
		tags: [
			"provoke",
			"dec-spd",
			"dec-acc"
		],
		gear: G.support,
		blurb: "The login legendary. Provoke and Decrease SPD make her a real Hydra Mischief tank.",
		aliases: ["visix"]
	}),
	c({
		id: "alice",
		name: "Alice the Wanderer",
		faction: "Sacred Order",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Attack",
		aura: "Increases ally ATK in all battles by 30%.",
		scores: {
			demon: 58,
			hydra: 64,
			chimera: 72
		},
		tags: [
			"buff-strip",
			"boss-dmg",
			"atk-aura"
		],
		gear: G.nuker,
		blurb: "Strips buffs, ignores a slice of defense, and carries a 30% attack aura. A damage aura piece more than a debuffer.",
		aliases: ["alice"]
	}),
	c({
		id: "greenwarden",
		name: "Greenwarden Ruarc",
		faction: "Sylvan Watchers",
		affinity: "Force",
		rarity: "Legendary",
		role: "Defense",
		scores: {
			demon: 66,
			hydra: 70,
			chimera: 76
		},
		tags: ["dec-atk", "shield"],
		gear: G.protector,
		blurb: "Decrease ATK, and he shields allies when they take a real hit. Useful padding on Chimera.",
		aliases: ["ruarc", "greenwarden"]
	}),
	c({
		id: "fayne",
		name: "Fayne",
		faction: "Skinwalkers",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Attack",
		scores: {
			demon: 94,
			hydra: 74,
			chimera: 86
		},
		tags: [
			"poison",
			"dec-def",
			"weaken",
			"dec-atk",
			"boss-dmg"
		],
		gear: G.debuffer,
		blurb: "The epic Draco. Poisons, Decrease DEF, Weaken, Decrease ATK, and extra damage into bosses.",
		aliases: ["fayne"]
	}),
	c({
		id: "fahrakin",
		name: "Fahrakin the Fat",
		faction: "Barbarians",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Attack",
		scores: {
			demon: 92,
			hydra: 82,
			chimera: 84
		},
		tags: [
			"hp-burn",
			"ally-attack",
			"poison",
			"inc-atk"
		],
		gear: G.debuffer,
		blurb: "Ally attack, HP Burn, poisons, and Increase ATK. He makes everyone else's Warmaster fire an extra time.",
		aliases: ["fatty", "fahrakin"]
	}),
	c({
		id: "toragi",
		name: "Toragi the Frog",
		faction: "Shadowkin",
		affinity: "Magic",
		rarity: "Epic",
		role: "HP",
		scores: {
			demon: 93,
			hydra: 76,
			chimera: 82
		},
		tags: [
			"ally-protect",
			"poison",
			"shield",
			"dec-atk"
		],
		gear: G.protector,
		blurb: "Ally protect, poisons, a shield, and Decrease ATK. The best epic protector for a classic Demon Lord team.",
		aliases: ["toragi", "frog"]
	}),
	c({
		id: "uugo",
		name: "Uugo",
		faction: "Ogryn Tribes",
		affinity: "Magic",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 78,
			hydra: 97,
			chimera: 86
		},
		tags: [
			"leech",
			"dec-def",
			"block-buffs",
			"heal",
			"cleanse"
		],
		gear: G.debuffer,
		blurb: "Decrease DEF and Block Buffs on one skill, plus Leech, a heal, and a cleanse. The epic you build first for Hydra.",
		aliases: ["uugo"]
	}),
	c({
		id: "anax",
		name: "Anax",
		faction: "Undead Hordes",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Attack",
		scores: {
			demon: 88,
			hydra: 68,
			chimera: 76
		},
		tags: [
			"poison",
			"dec-def",
			"weaken"
		],
		gear: G.debuffer,
		blurb: "Poisons with Decrease DEF and Weaken. A budget Draco when Fayne is the wrong affinity.",
		aliases: ["anax"]
	}),
	c({
		id: "stag-knight",
		name: "Stag Knight",
		faction: "Banner Lords",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 82,
			hydra: 86,
			chimera: 85
		},
		tags: ["dec-def", "dec-atk"],
		gear: G.debuffer,
		blurb: "AoE Decrease DEF and Decrease ATK. Simple, booked, and correct on every boss.",
		aliases: ["stag", "stag knight"]
	}),
	c({
		id: "dhukk",
		name: "Dhukk the Pierced",
		faction: "Orcs",
		affinity: "Magic",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 80,
			hydra: 82,
			chimera: 84
		},
		tags: [
			"dec-def",
			"dec-atk",
			"dec-acc"
		],
		gear: G.debuffer,
		blurb: "Decrease DEF, Decrease ATK, and Decrease ACC. A Magic-affinity Stag Knight with a defense body.",
		aliases: ["dhukk"]
	}),
	c({
		id: "deacon",
		name: "Deacon Armstrong",
		faction: "Sacred Order",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Support",
		aura: "Increases ally SPD in all battles.",
		scores: {
			demon: 84,
			hydra: 84,
			chimera: 82
		},
		tags: [
			"leech",
			"dec-def",
			"tm-boost",
			"speed-aura"
		],
		gear: G.support,
		blurb: "Speed aura, turn meter, Leech, and Decrease DEF. He leads and he debuffs.",
		aliases: ["deacon"]
	}),
	c({
		id: "hotatsu",
		name: "Hotatsu",
		faction: "Shadowkin",
		affinity: "Magic",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 86,
			hydra: 70,
			chimera: 78
		},
		tags: [
			"ally-protect",
			"dec-atk",
			"inc-def"
		],
		gear: G.protector,
		blurb: "Ally protect, Decrease ATK, and Increase DEF. A clean epic protector when Toragi is the wrong affinity.",
		aliases: ["hotatsu"]
	}),
	c({
		id: "demytha",
		name: "Demytha",
		faction: "Dwarves",
		affinity: "Void",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 95,
			hydra: 42,
			chimera: 40
		},
		tags: [
			"block-damage",
			"cleanse",
			"heal",
			"veil"
		],
		gear: G.unkillable,
		blurb: "The Myth-Heir Block Damage champion. Exact speeds, huge Demon Lord damage, little value once Lion ignores the buff.",
		aliases: ["demytha", "myth heir"]
	}),
	c({
		id: "maneater",
		name: "Maneater",
		faction: "Ogryn Tribes",
		affinity: "Void",
		rarity: "Epic",
		role: "HP",
		scores: {
			demon: 94,
			hydra: 34,
			chimera: 30
		},
		tags: ["unkillable", "dec-atk"],
		gear: G.unkillable,
		blurb: "Unkillable. Two of him, or one plus Painkeeper, is a full Ultra-Nightmare team. He is a tune piece, not a generalist.",
		aliases: ["maneater", "me"]
	}),
	c({
		id: "seeker",
		name: "Seeker",
		faction: "Undead Hordes",
		affinity: "Magic",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 86,
			hydra: 74,
			chimera: 60
		},
		tags: [
			"tm-boost",
			"inc-def",
			"provoke"
		],
		gear: G.unkillable,
		blurb: "Turn meter, Increase DEF, and Provoke. Required in several unkillable tunes, and a decent Hydra provoker.",
		aliases: ["seeker"]
	}),
	c({
		id: "skullcrusher",
		name: "Skullcrusher",
		faction: "Ogryn Tribes",
		affinity: "Force",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 88,
			hydra: 60,
			chimera: 62
		},
		tags: ["counter", "ally-protect"],
		gear: G.protector,
		blurb: "Counterattack and ally protect. The epic backbone of old-school counter teams.",
		aliases: ["skullcrusher", "sc"]
	}),
	c({
		id: "sepulcher",
		name: "Sepulcher Sentinel",
		faction: "Knight Revenant",
		affinity: "Force",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 88,
			hydra: 60,
			chimera: 74
		},
		tags: [
			"block-debuffs",
			"dec-atk",
			"inc-def"
		],
		gear: G.support,
		blurb: "Block Debuffs timed for the stun, plus Decrease ATK and Increase DEF. A classic 1:1 Demon Lord piece.",
		aliases: ["sepulcher", "sep sentinel"]
	}),
	c({
		id: "jareg",
		name: "Jareg",
		faction: "Lizardmen",
		affinity: "Magic",
		rarity: "Epic",
		role: "HP",
		scores: {
			demon: 82,
			hydra: 62,
			chimera: 70
		},
		tags: [
			"ally-protect",
			"dec-atk",
			"cont-heal"
		],
		gear: G.protector,
		blurb: "Ally protect, Decrease ATK, and continuous heals. A reliable epic tank.",
		aliases: ["jareg"]
	}),
	c({
		id: "doompriest",
		name: "Doompriest",
		faction: "Knight Revenant",
		affinity: "Force",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 84,
			hydra: 76,
			chimera: 82
		},
		tags: [
			"cleanse",
			"inc-atk",
			"heal"
		],
		gear: G.support,
		blurb: "Cleanses one debuff at the start of her turn, every turn. She deletes the stun without spending a skill.",
		aliases: ["doompriest", "dp"]
	}),
	c({
		id: "urogrim",
		name: "Urogrim",
		faction: "Ogryn Tribes",
		affinity: "Void",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 87,
			hydra: 74,
			chimera: 78
		},
		tags: [
			"poison",
			"cleanse",
			"heal"
		],
		gear: G.poison,
		blurb: "A Void mini Bad-el: poisons, cleanse, and heal, with no weak hits.",
		aliases: ["urogrim"]
	}),
	c({
		id: "venomage",
		name: "Venomage",
		faction: "Lizardmen",
		affinity: "Magic",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 86,
			hydra: 70,
			chimera: 74
		},
		tags: ["poison", "dec-atk"],
		gear: G.poison,
		blurb: "Poisons and Decrease ATK, and poisoned enemies hit your team softer. A strong Magic alternative to Fayne's damage setup.",
		aliases: ["venomage"]
	}),
	c({
		id: "occult-brawler",
		name: "Occult Brawler",
		faction: "Ogryn Tribes",
		affinity: "Spirit",
		rarity: "Epic",
		role: "HP",
		scores: {
			demon: 84,
			hydra: 40,
			chimera: 48
		},
		tags: ["poison"],
		gear: G.poison,
		blurb: "Poisons on the A1, over and over. Pure Demon Lord damage with no other job.",
		aliases: ["occult brawler", "ob"]
	}),
	c({
		id: "steelskull",
		name: "Steelskull",
		faction: "Skinwalkers",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 80,
			hydra: 66,
			chimera: 72
		},
		tags: [
			"poison",
			"heal",
			"cleanse"
		],
		gear: G.poison,
		blurb: "Poisons plus a heal and a cleanse. An older epic that still fills two holes.",
		aliases: ["steelskull"]
	}),
	c({
		id: "aox",
		name: "Aox the Rememberer",
		faction: "Lizardmen",
		affinity: "Force",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 80,
			hydra: 64,
			chimera: 70
		},
		tags: [
			"poison",
			"dec-atk",
			"heal",
			"cont-heal"
		],
		gear: G.poison,
		blurb: "Poisons, Decrease ATK, and heals. A Force-affinity bridge champion for midgame Demon Lord.",
		aliases: ["aox"]
	}),
	c({
		id: "rector",
		name: "Rector Drath",
		faction: "Knight Revenant",
		affinity: "Force",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 58,
			hydra: 55,
			chimera: 88
		},
		tags: [
			"perfect-veil",
			"cont-heal",
			"revive",
			"heal"
		],
		gear: G.support,
		blurb: "Perfect Veil, continuous heals, and a revive. Excellent on Chimera. Veil is awkward into Hydra Mischief, so she is not the Hydra reviver of choice.",
		aliases: ["rector", "rector drath"]
	}),
	c({
		id: "godseeker",
		name: "Godseeker Aniri",
		faction: "Sacred Order",
		affinity: "Void",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 52,
			hydra: 70,
			chimera: 76
		},
		tags: [
			"revive",
			"heal",
			"extend-buff"
		],
		gear: G.support,
		blurb: "A Void reviver who also extends buffs. She patches a dead champion and keeps shields in play.",
		aliases: ["aniri", "godseeker"]
	}),
	c({
		id: "vogoth",
		name: "Vogoth",
		faction: "Undead Hordes",
		affinity: "Spirit",
		rarity: "Epic",
		role: "HP",
		scores: {
			demon: 72,
			hydra: 76,
			chimera: 74
		},
		tags: [
			"leech",
			"provoke",
			"heal",
			"cont-heal"
		],
		gear: G.support,
		blurb: "Leech, Provoke, and passive healing when the team is hit. A bulky Hydra provoker.",
		aliases: ["vogoth"]
	}),
	c({
		id: "shamael",
		name: "Inquisitor Shamael",
		faction: "Sacred Order",
		affinity: "Void",
		rarity: "Epic",
		role: "Attack",
		scores: {
			demon: 40,
			hydra: 92,
			chimera: 58
		},
		tags: ["fear-cleanse", "strengthen"],
		gear: {
			...G.nuker,
			sets: "Savage or Lethal if he is also a damage dealer. Speed and 100% crit rate matter most — his A1 hits hard after he cleanses fear.",
			stats: "100% crit rate so the fear cleanse follow-up crits. Boots Speed. Accuracy is not his job."
		},
		blurb: "Cleanses fear and true fear, then hits. He is the answer to Hydra's Head of Torment.",
		aliases: ["shamael", "inquisitor"]
	}),
	c({
		id: "whisper",
		name: "Whisper",
		faction: "Knight Revenant",
		affinity: "Void",
		rarity: "Epic",
		role: "Attack",
		scores: {
			demon: 62,
			hydra: 86,
			chimera: 93
		},
		tags: [
			"weaken",
			"boss-dmg",
			"inc-atk",
			"inc-crit"
		],
		gear: G.nuker,
		blurb: "Void single-target boss damage and Weaken. A Chimera nuker you can actually book with epic tomes.",
		aliases: ["whisper"]
	}),
	c({
		id: "mordecai",
		name: "Mordecai",
		faction: "Sacred Order",
		affinity: "Force",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 64,
			hydra: 82,
			chimera: 60
		},
		tags: ["hp-burn", "aoe"],
		gear: G.burn,
		blurb: "AoE HP Burn on an epic. A Hydra burner while you wait on Artak.",
		aliases: ["mordecai"]
	}),
	c({
		id: "rugnor",
		name: "Rugnor Goldgleam",
		faction: "Dwarves",
		affinity: "Void",
		rarity: "Epic",
		role: "Attack",
		scores: {
			demon: 76,
			hydra: 70,
			chimera: 74
		},
		tags: [
			"leech",
			"dec-def",
			"weaken"
		],
		gear: G.debuffer,
		blurb: "Void Leech with Decrease DEF and Weaken. Three important debuffs and no weak hits.",
		aliases: ["rugnor"]
	}),
	c({
		id: "dazdurk",
		name: "Runekeeper Dazdurk",
		faction: "Dwarves",
		affinity: "Void",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 78,
			hydra: 60,
			chimera: 72
		},
		tags: [
			"leech",
			"extend-buff",
			"heal"
		],
		gear: G.support,
		blurb: "Leech and buff extension. He keeps Increase DEF, counterattack, or shields from falling off.",
		aliases: ["dazdurk", "runekeeper"]
	}),
	c({
		id: "sandlashed",
		name: "Sandlashed Survivor",
		faction: "Orcs",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 84,
			hydra: 48,
			chimera: 70
		},
		tags: ["extend-buff", "ally-protect"],
		gear: G.protector,
		blurb: "Extends buffs and ally protects. She is how counterattack and Block Debuffs last long enough on Demon Lord.",
		aliases: ["sandlashed"]
	}),
	c({
		id: "rearguard",
		name: "Rearguard Sergeant",
		faction: "Dwarves",
		affinity: "Force",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 76,
			hydra: 52,
			chimera: 60
		},
		tags: ["ally-protect", "dec-atk"],
		gear: G.protector,
		blurb: "Ally protect and Decrease ATK. A straightforward Force protector.",
		aliases: ["rearguard"]
	}),
	c({
		id: "grizzled-jarl",
		name: "Grizzled Jarl",
		faction: "Dwarves",
		affinity: "Magic",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 76,
			hydra: 58,
			chimera: 68
		},
		tags: [
			"block-debuffs",
			"dec-atk",
			"inc-def"
		],
		gear: G.support,
		blurb: "A Magic Sepulcher: Block Debuffs, Decrease ATK, and Increase DEF.",
		aliases: ["jarl", "grizzled jarl"]
	}),
	c({
		id: "warcaster",
		name: "Warcaster",
		faction: "Banner Lords",
		affinity: "Void",
		rarity: "Epic",
		role: "Support",
		scores: {
			demon: 78,
			hydra: 30,
			chimera: 34
		},
		tags: ["block-damage"],
		gear: G.unkillable,
		blurb: "Budget Block Damage for an unkillable tune. Do not bring him to Chimera expecting the buff to save you from Lion.",
		aliases: ["warcaster"]
	}),
	c({
		id: "versulf",
		name: "Versulf the Grim",
		faction: "Knight Revenant",
		affinity: "Force",
		rarity: "Legendary",
		role: "HP",
		scores: {
			demon: 74,
			hydra: 68,
			chimera: 70
		},
		tags: [
			"leech",
			"ally-attack",
			"inc-def"
		],
		gear: G.support,
		blurb: "Leech, ally attack, and Increase DEF. Extra turns for the damage dealers and healing from Leech.",
		aliases: ["versulf"]
	}),
	c({
		id: "tayrel",
		name: "Tayrel",
		faction: "High Elves",
		affinity: "Magic",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 80,
			hydra: 78,
			chimera: 80
		},
		tags: ["dec-def", "dec-atk"],
		gear: G.debuffer,
		blurb: "Decrease DEF and Decrease ATK on a defense champion. An old epic that still does the job.",
		aliases: ["tayrel"]
	}),
	c({
		id: "longbeard",
		name: "Longbeard",
		faction: "Skinwalkers",
		affinity: "Magic",
		rarity: "Legendary",
		role: "Attack",
		scores: {
			demon: 78,
			hydra: 70,
			chimera: 74
		},
		tags: ["ally-attack", "weaken"],
		gear: G.support,
		blurb: "Ally attack and Weaken. Extra hits for everyone, which is extra Warmaster and Giant Slayer procs.",
		aliases: ["longbeard"]
	}),
	c({
		id: "bulwark",
		name: "Bulwark",
		faction: "Dwarves",
		affinity: "Void",
		rarity: "Rare",
		role: "Defense",
		scores: {
			demon: 70,
			hydra: 40,
			chimera: 48
		},
		tags: ["ally-protect", "dec-atk"],
		gear: G.protector,
		blurb: "A rare ally protector with Decrease ATK. Fine on Nightmare while you build Toragi or Hotatsu.",
		aliases: ["bulwark"]
	}),
	c({
		id: "nazana",
		name: "Nazana",
		faction: "Demonspawn",
		affinity: "Force",
		rarity: "Epic",
		role: "HP",
		scores: {
			demon: 68,
			hydra: 48,
			chimera: 55
		},
		tags: ["ally-protect", "shield"],
		gear: G.protector,
		blurb: "Ally protect and a shield. A filler protector if the better ones are the wrong affinity.",
		aliases: ["nazana"]
	}),
	c({
		id: "ghrush",
		name: "Ghrush the Mangler",
		faction: "Ogryn Tribes",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Defense",
		scores: {
			demon: 66,
			hydra: 50,
			chimera: 52
		},
		tags: ["ally-protect", "dec-atk"],
		gear: G.protector,
		blurb: "Another epic ally protector with Decrease ATK. Use him when Toragi, Hotatsu, and Jareg are busy or missing.",
		aliases: ["ghrush", "grush"]
	}),
	c({
		id: "painkeeper",
		name: "Painkeeper",
		faction: "Dark Elves",
		affinity: "Void",
		rarity: "Rare",
		role: "HP",
		scores: {
			demon: 90,
			hydra: 36,
			chimera: 42
		},
		tags: ["cooldown-reduce", "heal"],
		gear: G.unkillable,
		blurb: "Reduces cooldowns and heals. She is the other half of Maneater, Demytha, and Helicath tunes. Her speed has to be exact.",
		aliases: [
			"painkeeper",
			"pk",
			"pain keeper"
		]
	}),
	c({
		id: "frozen-banshee",
		name: "Frozen Banshee",
		faction: "Undead Hordes",
		affinity: "Magic",
		rarity: "Rare",
		role: "Attack",
		scores: {
			demon: 86,
			hydra: 42,
			chimera: 50
		},
		tags: ["poison", "poison-sens"],
		gear: G.poison,
		blurb: "Poison sensitivity on a rare. With any other poisoner she is still a Demon Lord damage dealer in the late game.",
		aliases: [
			"frozen banshee",
			"fb",
			"banshee"
		]
	}),
	c({
		id: "kael",
		name: "Kael",
		faction: "Dark Elves",
		affinity: "Magic",
		rarity: "Rare",
		role: "Attack",
		scores: {
			demon: 68,
			hydra: 32,
			chimera: 38
		},
		tags: ["poison", "aoe"],
		gear: G.poison,
		blurb: "The starter poisoner. He gets you to Brutal and Nightmare. Replace him once Frozen Banshee or a real debuffer is built.",
		aliases: ["kael"]
	}),
	c({
		id: "apothecary",
		name: "Apothecary",
		faction: "High Elves",
		affinity: "Magic",
		rarity: "Rare",
		role: "Support",
		aura: "Increases ally SPD in all battles.",
		scores: {
			demon: 74,
			hydra: 70,
			chimera: 72
		},
		tags: [
			"heal",
			"inc-spd",
			"tm-boost",
			"speed-aura"
		],
		gear: G.support,
		blurb: "Speed aura, a heal, Increase SPD, and a three-hit A1 for Giant Slayer. The best rare support in the game.",
		aliases: ["apo", "apothecary"]
	}),
	c({
		id: "high-khatun",
		name: "High Khatun",
		faction: "Barbarians",
		affinity: "Spirit",
		rarity: "Epic",
		role: "Support",
		aura: "Increases ally SPD in all battles.",
		scores: {
			demon: 55,
			hydra: 64,
			chimera: 62
		},
		tags: [
			"speed-aura",
			"tm-boost",
			"inc-spd"
		],
		gear: G.support,
		blurb: "A speed aura and a turn meter boost. Fine as a lead. Do not drop her into a tuned unkillable team — the turn meter boost desyncs it.",
		aliases: [
			"hk",
			"high khatun",
			"khatun"
		]
	}),
	c({
		id: "renegade",
		name: "Renegade",
		faction: "Knight Revenant",
		affinity: "Void",
		rarity: "Rare",
		role: "Support",
		scores: {
			demon: 70,
			hydra: 28,
			chimera: 30
		},
		tags: ["cooldown-reduce"],
		gear: G.unkillable,
		blurb: "A rare cooldown reset. She exists for specific Demon Lord tunes and almost nothing else.",
		aliases: ["renegade"]
	}),
	c({
		id: "heiress",
		name: "Heiress",
		faction: "High Elves",
		affinity: "Force",
		rarity: "Rare",
		role: "Attack",
		scores: {
			demon: 66,
			hydra: 30,
			chimera: 34
		},
		tags: ["cleanse", "inc-spd"],
		gear: G.unkillable,
		blurb: "Cleanses and pushes speed. She is the rare cleanser inside Myth-Heir and similar tunes.",
		aliases: ["heiress"]
	}),
	c({
		id: "coffin-smasher",
		name: "Coffin Smasher",
		faction: "Knight Revenant",
		affinity: "Magic",
		rarity: "Rare",
		role: "HP",
		scores: {
			demon: 70,
			hydra: 55,
			chimera: 58
		},
		tags: ["hp-burn", "dec-atk"],
		gear: G.burn,
		blurb: "HP Burn and Decrease ATK on a rare. A decent early Decrease ATK until Stag Knight or Sepulcher is ready.",
		aliases: ["coffin smasher"]
	}),
	c({
		id: "marked",
		name: "Marked",
		faction: "Barbarians",
		affinity: "Magic",
		rarity: "Rare",
		role: "Support",
		scores: {
			demon: 64,
			hydra: 36,
			chimera: 40
		},
		tags: ["poison", "leech"],
		gear: G.poison,
		blurb: "Poisons and Leech on a rare. Leech lets the rest of the team skip Lifesteal sets.",
		aliases: ["marked"]
	}),
	c({
		id: "gravechill",
		name: "Gravechill Killer",
		faction: "Undead Hordes",
		affinity: "Magic",
		rarity: "Rare",
		role: "Attack",
		scores: {
			demon: 64,
			hydra: 30,
			chimera: 36
		},
		tags: ["poison"],
		gear: G.poison,
		blurb: "Extra poisons that pair with Frozen Banshee's sensitivity. Two rares, one real damage core.",
		aliases: ["gravechill", "gk"]
	}),
	c({
		id: "corpulent",
		name: "Corpulent Cadaver",
		faction: "Undead Hordes",
		affinity: "Spirit",
		rarity: "Rare",
		role: "HP",
		scores: {
			demon: 72,
			hydra: 40,
			chimera: 44
		},
		tags: ["poison", "ally-attack"],
		gear: G.poison,
		blurb: "Poisons and an ally attack on a rare. Surprisingly good Demon Lord damage for the investment.",
		aliases: ["corpulent", "cadaver"]
	}),
	c({
		id: "reliquary",
		name: "Reliquary Tender",
		faction: "High Elves",
		affinity: "Void",
		rarity: "Rare",
		role: "Support",
		scores: {
			demon: 60,
			hydra: 58,
			chimera: 66
		},
		tags: [
			"cleanse",
			"heal",
			"revive"
		],
		gear: G.support,
		blurb: "A rare Void cleanser with a heal and a single-target revive. Emergency coverage, not a damage plan.",
		aliases: ["reliquary", "rt"]
	})
];
var byId = new Map(CHAMPIONS.map((champ) => [champ.id, champ]));
function championById(id) {
	return byId.get(id);
}
function overallScore(champ) {
	const s = champ.scores;
	return Math.round((s.demon + s.hydra + s.chimera) / 3);
}
function searchChampions(query) {
	const q = query.trim().toLowerCase();
	if (q.length < 1) return [];
	return CHAMPIONS.filter((champ) => {
		return [
			champ.name,
			champ.faction,
			...champ.aliases ?? []
		].join(" ").toLowerCase().includes(q) || champ.aliases?.some((alias) => alias.startsWith(q));
	}).sort((a, b) => {
		const as = a.name.toLowerCase().startsWith(q) || a.aliases?.some((alias) => alias.startsWith(q)) ? 1 : 0;
		const bs = b.name.toLowerCase().startsWith(q) || b.aliases?.some((alias) => alias.startsWith(q)) ? 1 : 0;
		if (as !== bs) return bs - as;
		return overallScore(b) - overallScore(a);
	}).slice(0, 8);
}
var SAMPLE_IDS = [
	"gnut",
	"dracomorph",
	"geomancer",
	"wixwell",
	"brogni",
	"toragi",
	"fahrakin",
	"uugo",
	"mithrala",
	"pythion",
	"ninja",
	"fayne",
	"visix",
	"artak",
	"lydia",
	"shamael",
	"nekmo",
	"elva",
	"deacon",
	"hotatsu"
];
var TAG_LABEL = {
	poison: "Poison",
	"poison-sens": "Poison sensitivity",
	"hp-burn": "HP Burn",
	"enemy-max-hp": "Enemy max HP",
	"boss-dmg": "Bonus boss damage",
	"ally-attack": "Ally attack",
	"dec-def": "Decrease DEF",
	weaken: "Weaken",
	"dec-atk": "Decrease ATK",
	"dec-spd": "Decrease SPD",
	"dec-res": "Decrease RES",
	"dec-acc": "Decrease ACC",
	leech: "Leech",
	hex: "Hex",
	provoke: "Provoke",
	"block-buffs": "Block buffs",
	"extend-debuff": "Extend debuffs",
	"buff-strip": "Remove buffs",
	"ally-protect": "Ally protect",
	counter: "Counterattack",
	unkillable: "Unkillable",
	"block-damage": "Block damage",
	shield: "Shield",
	"shield-grow": "Shield growth",
	"inc-def": "Increase DEF",
	"inc-atk": "Increase ATK",
	"inc-crit": "Increase crit",
	"inc-spd": "Increase SPD",
	strengthen: "Strengthen",
	"cont-heal": "Continuous heal",
	heal: "Heal",
	cleanse: "Cleanse",
	"block-debuffs": "Block debuffs",
	revive: "Revive",
	"fear-cleanse": "Cleanse fear",
	veil: "Veil",
	"perfect-veil": "Perfect veil",
	reflect: "Damage reflect",
	"extend-buff": "Extend buffs",
	"tm-boost": "Turn meter boost",
	"cooldown-reduce": "Cooldown reduce",
	"speed-aura": "Speed aura",
	"def-aura": "Defense aura",
	"atk-aura": "Attack aura",
	"hp-aura": "HP aura",
	aoe: "AoE",
	intercept: "Intercept"
};
var TAG_GROUPS = [
	{
		title: "Damage",
		tags: [
			"poison",
			"poison-sens",
			"hp-burn",
			"enemy-max-hp",
			"boss-dmg",
			"ally-attack",
			"reflect"
		]
	},
	{
		title: "Debuffs",
		tags: [
			"dec-def",
			"weaken",
			"dec-atk",
			"dec-spd",
			"dec-res",
			"dec-acc",
			"leech",
			"hex",
			"provoke",
			"block-buffs",
			"extend-debuff",
			"buff-strip"
		]
	},
	{
		title: "Keep the team alive",
		tags: [
			"ally-protect",
			"counter",
			"unkillable",
			"block-damage",
			"shield",
			"shield-grow",
			"inc-def",
			"inc-atk",
			"inc-spd",
			"strengthen",
			"cont-heal",
			"heal",
			"cleanse",
			"block-debuffs",
			"revive",
			"fear-cleanse",
			"extend-buff",
			"intercept"
		]
	},
	{
		title: "Speed and auras",
		tags: [
			"tm-boost",
			"cooldown-reduce",
			"speed-aura",
			"def-aura",
			"atk-aura",
			"hp-aura"
		]
	}
];
function tagLabel(tag) {
	return TAG_LABEL[tag] ?? tag;
}
var DAMAGE = [
	"poison",
	"hp-burn",
	"enemy-max-hp",
	"boss-dmg"
];
var DEMON_TRAD = [
	{
		tag: "dec-def",
		first: 36,
		extra: 4
	},
	{
		tag: "weaken",
		first: 28,
		extra: 3
	},
	{
		tag: "dec-atk",
		first: 32,
		extra: 4
	},
	{
		tag: "poison",
		first: 22,
		extra: 12,
		cap: 3
	},
	{
		tag: "poison-sens",
		first: 18,
		extra: 2
	},
	{
		tag: "hp-burn",
		first: 22,
		extra: 4
	},
	{
		tag: "enemy-max-hp",
		first: 30,
		extra: 12
	},
	{
		tag: "boss-dmg",
		first: 14,
		extra: 4
	},
	{
		tag: "ally-protect",
		first: 26,
		extra: 6
	},
	{
		tag: "counter",
		first: 18,
		extra: 2
	},
	{
		tag: "leech",
		first: 14,
		extra: 1
	},
	{
		tag: "cleanse",
		first: 16,
		extra: 3
	},
	{
		tag: "block-debuffs",
		first: 16,
		extra: 2
	},
	{
		tag: "heal",
		first: 10,
		extra: 2
	},
	{
		tag: "cont-heal",
		first: 6,
		extra: 2
	},
	{
		tag: "shield",
		first: 10,
		extra: 4
	},
	{
		tag: "inc-def",
		first: 8,
		extra: 2
	},
	{
		tag: "strengthen",
		first: 8,
		extra: 1
	},
	{
		tag: "extend-debuff",
		first: 26,
		extra: 2
	},
	{
		tag: "extend-buff",
		first: 12,
		extra: 2
	},
	{
		tag: "ally-attack",
		first: 18,
		extra: 4
	},
	{
		tag: "reflect",
		first: 16,
		extra: 2
	},
	{
		tag: "speed-aura",
		first: 6,
		extra: 0
	},
	{
		tag: "def-aura",
		first: 4,
		extra: 0
	}
];
var DEMON_UK = [
	{
		tag: "unkillable",
		first: 40,
		extra: 22
	},
	{
		tag: "block-damage",
		first: 40,
		extra: 18
	},
	{
		tag: "cooldown-reduce",
		first: 28,
		extra: 8
	},
	{
		tag: "tm-boost",
		first: 14,
		extra: 2
	},
	{
		tag: "cleanse",
		first: 14,
		extra: 2
	},
	{
		tag: "block-debuffs",
		first: 12,
		extra: 2
	},
	{
		tag: "dec-def",
		first: 30,
		extra: 3
	},
	{
		tag: "weaken",
		first: 26,
		extra: 2
	},
	{
		tag: "dec-atk",
		first: 14,
		extra: 2
	},
	{
		tag: "poison",
		first: 20,
		extra: 10,
		cap: 3
	},
	{
		tag: "poison-sens",
		first: 16,
		extra: 2
	},
	{
		tag: "hp-burn",
		first: 20,
		extra: 4
	},
	{
		tag: "enemy-max-hp",
		first: 28,
		extra: 10
	},
	{
		tag: "boss-dmg",
		first: 12,
		extra: 4
	},
	{
		tag: "ally-attack",
		first: 14,
		extra: 3
	},
	{
		tag: "extend-debuff",
		first: 22,
		extra: 2
	},
	{
		tag: "reflect",
		first: 12,
		extra: 2
	},
	{
		tag: "leech",
		first: 6,
		extra: 0
	}
];
var DEMON_SHIELD = [
	{
		tag: "shield-grow",
		first: 48,
		extra: 4
	},
	{
		tag: "shield",
		first: 28,
		extra: 16
	},
	{
		tag: "reflect",
		first: 18,
		extra: 6
	},
	{
		tag: "inc-def",
		first: 12,
		extra: 3
	},
	{
		tag: "strengthen",
		first: 10,
		extra: 2
	},
	{
		tag: "extend-buff",
		first: 14,
		extra: 3
	},
	{
		tag: "enemy-max-hp",
		first: 32,
		extra: 8
	},
	{
		tag: "boss-dmg",
		first: 14,
		extra: 4
	},
	{
		tag: "hp-burn",
		first: 16,
		extra: 4
	},
	{
		tag: "poison",
		first: 12,
		extra: 4
	},
	{
		tag: "dec-def",
		first: 22,
		extra: 3
	},
	{
		tag: "weaken",
		first: 20,
		extra: 2
	},
	{
		tag: "dec-atk",
		first: 12,
		extra: 2
	},
	{
		tag: "counter",
		first: 8,
		extra: 2
	},
	{
		tag: "ally-attack",
		first: 10,
		extra: 2
	}
];
var HYDRA = [
	{
		tag: "provoke",
		first: 40,
		extra: 6
	},
	{
		tag: "block-buffs",
		first: 38,
		extra: 4
	},
	{
		tag: "dec-def",
		first: 26,
		extra: 4
	},
	{
		tag: "weaken",
		first: 20,
		extra: 3
	},
	{
		tag: "hp-burn",
		first: 26,
		extra: 14,
		cap: 3
	},
	{
		tag: "hex",
		first: 18,
		extra: 3
	},
	{
		tag: "enemy-max-hp",
		first: 22,
		extra: 8
	},
	{
		tag: "poison",
		first: 10,
		extra: 4
	},
	{
		tag: "cleanse",
		first: 22,
		extra: 4
	},
	{
		tag: "fear-cleanse",
		first: 24,
		extra: 2
	},
	{
		tag: "block-debuffs",
		first: 16,
		extra: 3
	},
	{
		tag: "revive",
		first: 14,
		extra: 3
	},
	{
		tag: "heal",
		first: 12,
		extra: 3
	},
	{
		tag: "leech",
		first: 12,
		extra: 2
	},
	{
		tag: "dec-spd",
		first: 12,
		extra: 3
	},
	{
		tag: "dec-atk",
		first: 12,
		extra: 3
	},
	{
		tag: "inc-spd",
		first: 10,
		extra: 2
	},
	{
		tag: "tm-boost",
		first: 10,
		extra: 2
	},
	{
		tag: "shield",
		first: 10,
		extra: 4
	},
	{
		tag: "ally-protect",
		first: 8,
		extra: 2
	},
	{
		tag: "speed-aura",
		first: 8,
		extra: 0
	},
	{
		tag: "perfect-veil",
		first: -6,
		extra: -4
	},
	{
		tag: "veil",
		first: -4,
		extra: -2
	}
];
var CHIMERA = [
	{
		tag: "dec-def",
		first: 32,
		extra: 4
	},
	{
		tag: "weaken",
		first: 28,
		extra: 3
	},
	{
		tag: "dec-spd",
		first: 16,
		extra: 3
	},
	{
		tag: "dec-atk",
		first: 14,
		extra: 3
	},
	{
		tag: "dec-res",
		first: 10,
		extra: 2
	},
	{
		tag: "leech",
		first: 12,
		extra: 1
	},
	{
		tag: "heal",
		first: 20,
		extra: 4
	},
	{
		tag: "cont-heal",
		first: 14,
		extra: 3
	},
	{
		tag: "revive",
		first: 22,
		extra: 4
	},
	{
		tag: "cleanse",
		first: 20,
		extra: 4
	},
	{
		tag: "block-debuffs",
		first: 16,
		extra: 3
	},
	{
		tag: "shield",
		first: 22,
		extra: 10
	},
	{
		tag: "shield-grow",
		first: 26,
		extra: 4
	},
	{
		tag: "inc-def",
		first: 12,
		extra: 3
	},
	{
		tag: "inc-atk",
		first: 10,
		extra: 2
	},
	{
		tag: "inc-spd",
		first: 8,
		extra: 2
	},
	{
		tag: "strengthen",
		first: 10,
		extra: 2
	},
	{
		tag: "ally-protect",
		first: 12,
		extra: 3
	},
	{
		tag: "hp-burn",
		first: 14,
		extra: 4
	},
	{
		tag: "poison",
		first: 12,
		extra: 4
	},
	{
		tag: "enemy-max-hp",
		first: 26,
		extra: 8
	},
	{
		tag: "boss-dmg",
		first: 16,
		extra: 4
	},
	{
		tag: "block-damage",
		first: 4,
		extra: 0
	},
	{
		tag: "unkillable",
		first: 2,
		extra: 0
	},
	{
		tag: "hex",
		first: 8,
		extra: 2
	},
	{
		tag: "buff-strip",
		first: 6,
		extra: 1
	}
];
function countTag(roster, tag) {
	return roster.filter((o) => o.champ.tags.includes(tag)).length;
}
var ARCHETYPES = {
	demon: [
		{
			id: "shield",
			label: "Shield growth",
			note: "Wixwell grows the shield every turn. Pair him with another shielder and a defense-based nuker. Speeds still have to be tuned, but the team does not rely on Unkillable.",
			weights: DEMON_SHIELD,
			enabled: (roster) => countTag(roster, "shield-grow") >= 1 && (countTag(roster, "shield") >= 2 || countTag(roster, "reflect") >= 1)
		},
		{
			id: "unkillable",
			label: "Unkillable tune",
			note: "Block Damage or Unkillable on a fixed speed tune. This is the most reliable Ultra-Nightmare plan if the speeds are exact. It is a poor Chimera plan, and Lion ignores both buffs.",
			weights: DEMON_UK,
			enabled: (roster) => {
				const uk = countTag(roster, "unkillable");
				const bd = countTag(roster, "block-damage");
				const cd = countTag(roster, "cooldown-reduce");
				return uk >= 2 || bd >= 2 || uk >= 1 && bd >= 1 || bd >= 1 && cd >= 1 || uk >= 1 && cd >= 1;
			}
		},
		{
			id: "classic",
			label: "Classic survival",
			note: "Decrease ATK, ally protect or a counterattack, then poisons or burns. Works from Nightmare upward. Someone needs Leech, or the damage dealers wear Lifesteal.",
			weights: DEMON_TRAD,
			enabled: () => true
		}
	],
	hydra: [{
		id: "heads",
		label: "Head control",
		note: "Six champions. Provoke so Mischief cannot eat your buffs, and Block Buffs so Suffering cannot cleanse you. Burns land per head, so more than one burner is useful. You cannot reuse a champion on another Hydra key this week.",
		weights: HYDRA,
		enabled: () => true
	}],
	chimera: [{
		id: "forms",
		label: "Form control",
		note: "Five champions across 65 turns and four forms. Keep buffs up — the Ultimate form punishes an unbuffed team. Bring a cleanse for Viper and a revive for Necrosis. Do not trust Unkillable or Block Damage: Lion ignores both.",
		weights: CHIMERA,
		enabled: () => true
	}]
};
var TEAM_SIZE = {
	demon: 5,
	hydra: 6,
	chimera: 5
};
var BOSS_META = {
	demon: {
		name: "Demon Lord",
		size: 5,
		keys: "One team, up to four keys a day. The same five usually run every key.",
		targets: [
			"Accuracy 250 on Ultra-Nightmare for anyone landing a debuff.",
			"About 3,500 DEF and 40,000 HP if you are not in an unkillable tune.",
			"Speed is the tune, not a vibe. 171–189 is a common 1:1 range. 2:1 wants 251+. Unkillable comps use exact speeds."
		]
	},
	hydra: {
		name: "Hydra",
		size: 6,
		keys: "Three keys. Champions lock for the week — each key needs a different six.",
		targets: [
			"Nightmare accuracy is about 350. Lower difficulties ask for less.",
			"Provoke for Mischief. Block Buffs for Suffering. A fear cleanse for Torment.",
			"HP Burn is the damage engine. One burn per head, not three burns on one head."
		]
	},
	chimera: {
		name: "Chimera",
		size: 5,
		keys: "Five champions, exactly 65 turns, two keys. The same five can run both keys.",
		targets: [
			"Accuracy about 25 over the boss resistance for that difficulty.",
			"Buff uptime matters: Increase DEF, shields, Block Debuffs, heals.",
			"Ram reflects. Viper poisons. Lion ignores Unkillable and Block Damage. Ultimate wants your team buffed."
		]
	}
};
var COVERAGE = {
	demon: [
		{
			id: "def",
			label: "Decrease DEF",
			tags: ["dec-def"]
		},
		{
			id: "weak",
			label: "Weaken",
			tags: ["weaken"]
		},
		{
			id: "atk",
			label: "Decrease ATK",
			tags: ["dec-atk"]
		},
		{
			id: "dmg",
			label: "Poison, burn, or max HP",
			tags: DAMAGE
		},
		{
			id: "live",
			label: "Protect or unkillable",
			tags: [
				"ally-protect",
				"unkillable",
				"block-damage",
				"counter",
				"shield-grow"
			]
		},
		{
			id: "safe",
			label: "Cleanse, leech, or shields",
			tags: [
				"cleanse",
				"block-debuffs",
				"leech",
				"shield-grow"
			]
		}
	],
	hydra: [
		{
			id: "prov",
			label: "Provoke",
			tags: ["provoke"]
		},
		{
			id: "block",
			label: "Block buffs",
			tags: ["block-buffs"]
		},
		{
			id: "def",
			label: "Decrease DEF",
			tags: ["dec-def"]
		},
		{
			id: "burn",
			label: "HP Burn",
			tags: ["hp-burn"]
		},
		{
			id: "clean",
			label: "Cleanse",
			tags: [
				"cleanse",
				"block-debuffs",
				"fear-cleanse"
			]
		},
		{
			id: "hex",
			label: "Hex or Weaken",
			tags: ["hex", "weaken"]
		}
	],
	chimera: [
		{
			id: "def",
			label: "Decrease DEF",
			tags: ["dec-def"]
		},
		{
			id: "weak",
			label: "Weaken",
			tags: ["weaken"]
		},
		{
			id: "heal",
			label: "Heal",
			tags: [
				"heal",
				"cont-heal",
				"leech"
			]
		},
		{
			id: "clean",
			label: "Cleanse",
			tags: ["cleanse", "block-debuffs"]
		},
		{
			id: "rev",
			label: "Revive",
			tags: ["revive"]
		},
		{
			id: "shield",
			label: "Shield or strengthen",
			tags: [
				"shield",
				"strengthen",
				"inc-def"
			]
		}
	]
};
function tagCounts(team) {
	const counts = {};
	for (const member of team) {
		const seen = /* @__PURE__ */ new Set();
		for (const tag of member.champ.tags) {
			if (seen.has(tag)) continue;
			seen.add(tag);
			counts[tag] = (counts[tag] ?? 0) + 1;
		}
	}
	return counts;
}
var WEAK_AGAINST = {
	Magic: "Force",
	Force: "Spirit",
	Spirit: "Magic",
	Void: null
};
var STRONG_AGAINST = {
	Magic: "Spirit",
	Force: "Magic",
	Spirit: "Force",
	Void: null
};
function affinityWord(champ, boss) {
	if (boss === "Any" || champ === "Void") return "neutral";
	if (WEAK_AGAINST[champ] === boss) return "weak";
	if (STRONG_AGAINST[champ] === boss) return "strong";
	return "neutral";
}
function affinityScore(team, boss, affinity) {
	let score = 0;
	if (boss === "hydra" && affinity === "Any") {
		const kinds = new Set(team.map((m) => m.champ.affinity).filter((a) => a !== "Void"));
		score += Math.min(3, kinds.size) * 4;
		if (team.some((m) => m.champ.affinity === "Void")) score += 6;
		return score;
	}
	for (const member of team) {
		const word = affinityWord(member.champ.affinity, affinity);
		if (word === "weak") score -= 18;
		else if (word === "strong") score += 6;
		else if (member.champ.affinity === "Void" && affinity !== "Any") score += 4;
	}
	return score;
}
function synergy(counts, boss, archetypeId) {
	let score = 0;
	if (counts["dec-def"] && counts["weaken"]) score += 12;
	if (counts["poison"] && counts["poison-sens"]) score += 16;
	if (counts["unkillable"] && counts["cooldown-reduce"]) score += 20;
	if (counts["block-damage"] && counts["cooldown-reduce"]) score += 20;
	if (counts["block-damage"] && counts["tm-boost"]) score += 8;
	if ((counts["shield-grow"] ?? 0) >= 1 && (counts["shield"] ?? 0) >= 2) score += 30;
	if (counts["shield-grow"] && counts["reflect"] && counts["enemy-max-hp"]) score += 42;
	if (counts["hp-burn"] && counts["ally-attack"]) score += 8;
	if (counts["poison"] && counts["extend-debuff"]) score += 18;
	if (boss === "hydra" && counts["provoke"] && counts["block-buffs"]) score += 16;
	if (boss === "chimera" && counts["revive"] && counts["cleanse"]) score += 10;
	if (boss === "demon" && archetypeId === "unkillable") {
		if ((counts["unkillable"] ?? 0) + (counts["block-damage"] ?? 0) < 1) score -= 30;
	}
	if ((counts["poison"] ?? 0) + (counts["hp-burn"] ?? 0) + (counts["enemy-max-hp"] ?? 0) + (counts["boss-dmg"] ?? 0) + (counts["reflect"] ?? 0) > 0) score += 12;
	return score;
}
function teamScore(team, boss, affinity, weights, archetypeId) {
	let score = 0;
	for (const member of team) score += member.champ.scores[boss];
	const counts = tagCounts(team);
	for (const weight of weights) {
		const n = Math.min(counts[weight.tag] ?? 0, weight.cap ?? 6);
		if (n <= 0) continue;
		score += weight.first + weight.extra * (n - 1);
	}
	score += synergy(counts, boss, archetypeId);
	score += affinityScore(team, boss, affinity);
	return score;
}
function optimizeArchetype(roster, boss, affinity, archetype) {
	const size = Math.min(TEAM_SIZE[boss], roster.length);
	if (size === 0) return [];
	let beam = [[]];
	const width = 24;
	for (let slot = 0; slot < size; slot += 1) {
		const next = [];
		for (const partial of beam) {
			const used = new Set(partial.map((m) => m.uid));
			for (const candidate of roster) {
				if (used.has(candidate.uid)) continue;
				const team = [...partial, candidate];
				next.push({
					team,
					score: teamScore(team, boss, affinity, archetype.weights, archetype.id)
				});
			}
		}
		next.sort((a, b) => b.score - a.score);
		const seen = /* @__PURE__ */ new Set();
		beam = [];
		for (const row of next) {
			const key = row.team.map((m) => m.uid).sort().join(":");
			if (seen.has(key)) continue;
			seen.add(key);
			beam.push(row.team);
			if (beam.length >= width) break;
		}
	}
	let best = beam.map((team) => ({
		team,
		score: teamScore(team, boss, affinity, archetype.weights, archetype.id)
	})).sort((a, b) => b.score - a.score)[0]?.team ?? [];
	let improved = true;
	let guard = 0;
	while (improved && guard < 6) {
		improved = false;
		guard += 1;
		const base = teamScore(best, boss, affinity, archetype.weights, archetype.id);
		for (let i = 0; i < best.length; i += 1) {
			for (const candidate of roster) {
				if (best.some((m) => m.uid === candidate.uid)) continue;
				const trial = best.slice();
				trial[i] = candidate;
				if (teamScore(trial, boss, affinity, archetype.weights, archetype.id) > base + .5) {
					best = trial;
					improved = true;
					break;
				}
			}
			if (improved) break;
		}
	}
	return best;
}
function whyFor(member, team, boss) {
	const counts = tagCounts(team);
	const important = new Set(COVERAGE[boss].flatMap((item) => item.tags).concat(boss === "demon" ? [
		"shield-grow",
		"unkillable",
		"block-damage",
		"extend-debuff",
		"ally-attack",
		"enemy-max-hp"
	] : []));
	const unique = member.champ.tags.filter((tag) => important.has(tag) && counts[tag] === 1);
	const shared = member.champ.tags.filter((tag) => important.has(tag) && (counts[tag] ?? 0) > 1);
	if (unique.length > 0) return `Only slot covering ${unique.map(tagLabel).join(", ")}.`;
	if (shared.length > 0) return `Backs up ${shared.slice(0, 3).map(tagLabel).join(", ")}.`;
	return member.champ.blurb;
}
function warningsFor(team, boss) {
	const counts = tagCounts(team);
	const notes = [];
	if (boss === "hydra") {
		if (!counts["provoke"]) notes.push("No Provoke. Mischief will steal your buffs and throw them back.");
		if (!counts["block-buffs"]) notes.push("No Block Buffs. Suffering cleanses the debuffs you just landed.");
		if (!counts["fear-cleanse"]) notes.push("No fear cleanse. Torment will fear the team unless someone else handles it.");
	}
	if (boss === "chimera") {
		if ((counts["unkillable"] || counts["block-damage"]) && !counts["heal"] && !counts["shield"]) notes.push("This team is leaning on Unkillable or Block Damage. Lion form ignores both.");
		if (!counts["cleanse"] && !counts["block-debuffs"]) notes.push("No cleanse. Viper's poisons will sit for the whole form.");
		if (!counts["revive"]) notes.push("No revive. A dead champion feeds Necrosis.");
	}
	if (boss === "demon") {
		if (!(DAMAGE.some((tag) => counts[tag]) || counts["reflect"])) notes.push("No poison, burn, or max-HP damage. The team will survive and do very little.");
		if (!counts["dec-def"]) notes.push("No Decrease DEF. Damage is roughly cut in half.");
		if (!counts["leech"] && !counts["unkillable"] && !counts["block-damage"] && !counts["shield-grow"]) notes.push("No Leech and no unkillable plan. Put the damage dealers in Lifesteal, or add a Leech champion.");
	}
	return notes;
}
function suggestionsFor(roster, team, boss) {
	const ownedIds = new Set(roster.map((m) => m.champ.id));
	const counts = tagCounts(team);
	const missing = COVERAGE[boss].filter((item) => !item.tags.some((tag) => (counts[tag] ?? 0) > 0));
	const out = [];
	for (const gap of missing) {
		const pick = CHAMPIONS.filter((champ) => !ownedIds.has(champ.id) && champ.tags.some((tag) => gap.tags.includes(tag))).sort((a, b) => b.scores[boss] - a.scores[boss])[0];
		if (pick && !out.some((row) => row.champ.id === pick.id)) out.push({
			champ: pick,
			reason: `Would cover ${gap.label}.`
		});
	}
	return out.slice(0, 3);
}
function orderTurn(team) {
	if (team.every((m) => m.speed && m.speed > 0)) return [...team].sort((a, b) => (b.speed ?? 0) - (a.speed ?? 0));
	const rank = (champ) => {
		const tags = new Set(champ.tags);
		if (tags.has("speed-aura") || tags.has("tm-boost") || tags.has("inc-spd")) return 1;
		if (tags.has("unkillable") || tags.has("block-damage") || tags.has("block-debuffs") || tags.has("shield-grow")) return 2;
		if (tags.has("dec-atk") || tags.has("ally-protect") || tags.has("provoke")) return 3;
		if (tags.has("dec-def") || tags.has("weaken") || tags.has("cleanse")) return 4;
		return 5;
	};
	return [...team].sort((a, b) => rank(a.champ) - rank(b.champ) || a.champ.name.localeCompare(b.champ.name));
}
function decorate(team, roster, boss, affinity, archetype, score) {
	const counts = tagCounts(team);
	const members = team.map((owned) => ({
		owned,
		contribution: 0,
		why: whyFor(owned, team, boss),
		weak: affinityWord(owned.champ.affinity, affinity) === "weak"
	})).map((member) => {
		const without = team.filter((other) => other.uid !== member.owned.uid);
		const full = teamScore(team, boss, affinity, archetype.weights, archetype.id);
		const rest = teamScore(without, boss, affinity, archetype.weights, archetype.id);
		return {
			...member,
			contribution: Math.max(0, Math.round(full - rest))
		};
	}).sort((a, b) => b.contribution - a.contribution);
	return {
		boss,
		archetypeId: archetype.id,
		archetype: archetype.label,
		note: archetype.note,
		members,
		coverage: COVERAGE[boss].map((item) => ({
			id: item.id,
			label: item.label,
			met: item.tags.some((tag) => (counts[tag] ?? 0) > 0)
		})),
		turnOrder: orderTurn(team),
		suggestions: suggestionsFor(roster, team, boss),
		warnings: warningsFor(team, boss),
		score
	};
}
function buildTeam(roster, boss, affinity) {
	if (roster.length === 0) return null;
	const ranked = ARCHETYPES[boss].filter((archetype) => archetype.enabled(roster)).map((archetype) => {
		const team = optimizeArchetype(roster, boss, affinity, archetype);
		return {
			archetype,
			team,
			score: teamScore(team, boss, affinity, archetype.weights, archetype.id)
		};
	}).sort((a, b) => b.score - a.score);
	const best = ranked[0];
	if (!best) return null;
	const counts = tagCounts(best.team);
	let shown = best.archetype;
	if (boss === "demon" && counts["shield-grow"] && counts["reflect"] && shown.id !== "shield") shown = ARCHETYPES.demon.find((row) => row.id === "shield") ?? shown;
	if (boss === "demon" && ((counts["unkillable"] ?? 0) >= 2 || (counts["unkillable"] ?? 0) >= 1 && (counts["block-damage"] ?? 0) >= 1 || (counts["block-damage"] ?? 0) >= 1 && (counts["cooldown-reduce"] ?? 0) >= 1) && shown.id !== "unkillable") shown = ARCHETYPES.demon.find((row) => row.id === "unkillable") ?? shown;
	const plan = decorate(best.team, roster, boss, affinity, shown, best.score);
	const second = ranked[1];
	if (second && second.score >= best.score * .9 && second.archetype.id !== shown.id && second.archetype.id !== best.archetype.id) plan.runnerUp = {
		archetype: second.archetype.label,
		note: `${second.archetype.label} is close. Use it if you cannot hit the speeds for ${shown.label}.`
	};
	return plan;
}
function buildHydraKeys(roster, affinity) {
	const plans = [];
	let pool = roster.slice();
	for (let key = 0; key < 3; key += 1) {
		if (pool.length === 0) break;
		const plan = buildTeam(pool, "hydra", affinity);
		if (!plan || plan.members.length === 0) break;
		plans.push(plan);
		const used = new Set(plan.members.map((m) => m.owned.uid));
		pool = pool.filter((m) => !used.has(m.uid));
	}
	return plans;
}
function gearForTags(tags, role) {
	if (tags.includes("unkillable") || tags.includes("block-damage") && tags.includes("cooldown-reduce")) return GEAR.unkillable;
	if (tags.includes("shield-grow")) return GEAR.shield;
	if (tags.includes("enemy-max-hp") && role === "Defense") return GEAR.nukerDef;
	if (tags.includes("enemy-max-hp") || tags.includes("boss-dmg")) return GEAR.nuker;
	if (tags.includes("ally-protect")) return GEAR.protector;
	if (tags.includes("hp-burn")) return GEAR.burn;
	if (tags.includes("poison") || tags.includes("poison-sens")) return GEAR.poison;
	if (tags.includes("dec-def") || tags.includes("weaken") || tags.includes("dec-atk") || tags.includes("block-buffs")) return GEAR.debuffer;
	return GEAR.support;
}
function scoresFromTags(tags) {
	const tables = {
		demon: {
			"dec-def": 14,
			weaken: 12,
			"dec-atk": 12,
			poison: 12,
			"poison-sens": 10,
			"hp-burn": 10,
			"enemy-max-hp": 16,
			"boss-dmg": 8,
			"ally-protect": 12,
			counter: 10,
			unkillable: 16,
			"block-damage": 16,
			"shield-grow": 16,
			leech: 6,
			cleanse: 8,
			"extend-debuff": 14,
			"ally-attack": 10,
			reflect: 10
		},
		hydra: {
			provoke: 16,
			"block-buffs": 16,
			"dec-def": 10,
			weaken: 8,
			"hp-burn": 14,
			hex: 10,
			"enemy-max-hp": 12,
			cleanse: 10,
			"fear-cleanse": 14,
			revive: 6,
			leech: 6,
			"dec-spd": 6
		},
		chimera: {
			"dec-def": 12,
			weaken: 12,
			heal: 10,
			"cont-heal": 8,
			revive: 12,
			cleanse: 10,
			"block-debuffs": 8,
			shield: 10,
			"shield-grow": 12,
			"enemy-max-hp": 14,
			"boss-dmg": 10,
			"inc-def": 6,
			strengthen: 6
		}
	};
	const score = (boss) => {
		let value = 28;
		const seen = /* @__PURE__ */ new Set();
		for (const tag of tags) {
			if (seen.has(tag)) continue;
			seen.add(tag);
			value += tables[boss][tag] ?? 2;
		}
		return Math.max(20, Math.min(88, value));
	};
	return {
		demon: score("demon"),
		hydra: score("hydra"),
		chimera: score("chimera")
	};
}
function rankRoster(roster, boss) {
	return [...roster].sort((a, b) => {
		const as = boss === "overall" ? overallScore(a.champ) : a.champ.scores[boss];
		return (boss === "overall" ? overallScore(b.champ) : b.champ.scores[boss]) - as || a.champ.name.localeCompare(b.champ.name);
	});
}
function bossScore(champ, boss) {
	return boss === "overall" ? overallScore(champ) : champ.scores[boss];
}
function uid() {
	return crypto.randomUUID();
}
var useRoster = create()(persist((set, get) => ({
	entries: [],
	customs: [],
	affinity: {
		demon: "Void",
		hydra: "Any",
		chimera: "Void"
	},
	addCatalog: (id) => {
		if (!championById(id)) return;
		if (get().entries.length >= 60) return;
		set({ entries: [...get().entries, {
			uid: uid(),
			championId: id,
			speed: null
		}] });
	},
	addCustom: (draft) => {
		if (get().entries.length >= 60) return;
		const name = draft.name.trim().slice(0, 40);
		if (!name) return;
		const id = `custom-${uid()}`;
		const tags = draft.tags;
		const champ = {
			id,
			name,
			faction: "Your vault",
			affinity: draft.affinity,
			rarity: draft.rarity,
			role: draft.role,
			scores: scoresFromTags(tags),
			tags,
			gear: gearForTags(tags, draft.role),
			blurb: "Custom champion. Ratings come from the roles you toggled, not a tested kit."
		};
		set({
			customs: [...get().customs, champ],
			entries: [...get().entries, {
				uid: uid(),
				championId: id,
				speed: null
			}]
		});
	},
	remove: (id) => {
		const entry = get().entries.find((row) => row.uid === id);
		set({
			entries: get().entries.filter((row) => row.uid !== id),
			customs: entry?.championId.startsWith("custom-") ? get().customs.filter((champ) => champ.id !== entry.championId) : get().customs
		});
	},
	setSpeed: (id, speed) => {
		set({ entries: get().entries.map((row) => row.uid === id ? {
			...row,
			speed
		} : row) });
	},
	setAffinity: (boss, affinity) => set({ affinity: {
		...get().affinity,
		[boss]: affinity
	} }),
	loadSample: () => {
		const have = new Set(get().entries.map((row) => row.championId));
		const next = [...get().entries];
		for (const id of SAMPLE_IDS) {
			if (have.has(id) || next.length >= 60) continue;
			next.push({
				uid: uid(),
				championId: id,
				speed: null
			});
		}
		set({ entries: next });
	},
	clear: () => set({
		entries: [],
		customs: []
	})
}), {
	name: "ashen-keys-vault",
	skipHydration: true
}));
function resolveOwned(entries, customs) {
	const customMap = new Map(customs.map((champ) => [champ.id, champ]));
	const owned = [];
	for (const entry of entries) {
		const champ = championById(entry.championId) ?? customMap.get(entry.championId);
		if (!champ) continue;
		owned.push({
			uid: entry.uid,
			champ,
			speed: entry.speed
		});
	}
	return owned;
}
var AFFINITIES = [
	"Magic",
	"Force",
	"Spirit",
	"Void"
];
var RARITY_OPTIONS = [
	"Mythical",
	"Legendary",
	"Epic",
	"Rare"
];
var ROLES = [
	"Attack",
	"Defense",
	"HP",
	"Support"
];
function affinityClass(affinity) {
	if (affinity === "Magic") return "bg-magic";
	if (affinity === "Force") return "bg-force";
	if (affinity === "Spirit") return "bg-spirit";
	return "bg-void";
}
function affinityText(affinity) {
	if (affinity === "Magic") return "text-magic";
	if (affinity === "Force") return "text-force";
	if (affinity === "Spirit") return "text-spirit";
	return "text-void";
}
function AshenApp() {
	const [tab, setTab] = (0, import_react.useState)("vault");
	const entries = useRoster((s) => s.entries);
	const customs = useRoster((s) => s.customs);
	const affinity = useRoster((s) => s.affinity);
	(0, import_react.useEffect)(() => {
		useRoster.persist.rehydrate();
	}, []);
	const owned = (0, import_react.useMemo)(() => resolveOwned(entries, customs), [entries, customs]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center gap-3 px-4 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-11 items-center justify-center rounded-md bg-raised text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-gold uppercase",
								children: "War room"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-2xl leading-none text-fg",
								children: "Ashen Keys"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "ml-auto text-right text-sm text-muted tabular-nums",
							children: [owned.length, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs",
								children: "in vault"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-3xl px-4 pt-5 pb-nav",
				children: [
					tab === "vault" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vault, { owned }) : null,
					tab === "teams" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Teams, {
						owned,
						affinity
					}) : null,
					tab === "ranks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ranks, { owned }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "nav-safe fixed inset-x-0 bottom-0 border-t border-border bg-surface",
				"aria-label": "Sections",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-3xl grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							active: tab === "vault",
							onClick: () => setTab("vault"),
							label: "Vault",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							active: tab === "teams",
							onClick: () => setTab("teams"),
							label: "Teams",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							active: tab === "ranks",
							onClick: () => setTab("ranks"),
							label: "Rank",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListOrdered, { className: "size-5" })
						})
					]
				})
			})
		]
	});
}
function NavButton({ active, onClick, label, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-current": active ? "page" : void 0,
		className: `flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium ${active ? "text-primary" : "text-muted"}`,
		children: [icon, label]
	});
}
function Vault({ owned }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [customOpen, setCustomOpen] = (0, import_react.useState)(false);
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	const addCatalog = useRoster((s) => s.addCatalog);
	const loadSample = useRoster((s) => s.loadSample);
	const clear = useRoster((s) => s.clear);
	const results = searchChampions(query);
	const counts = /* @__PURE__ */ new Map();
	for (const row of owned) counts.set(row.champ.id, (counts.get(row.champ.id) ?? 0) + 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Add the champions you actually own. Teams take five for Demon Lord and Chimera, six for Hydra. Duplicates are allowed — two Maneaters is a real tune."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "champ-search",
						children: "Search champions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "pointer-events-none absolute top-3.5 left-3 size-5 text-faint",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "champ-search",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Search Gnut, Uugo, Geomancer…",
						autoComplete: "off",
						className: "h-12 w-full rounded-md border border-border bg-surface pr-12 pl-11 text-base text-fg placeholder:text-faint"
					}),
					query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Clear search",
						onClick: () => setQuery(""),
						className: "absolute top-1 right-1 flex size-10 items-center justify-center text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					}) : null,
					results.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "absolute z-10 mt-2 max-h-80 w-full overflow-auto rounded-md border border-border bg-surface",
						children: results.map((champ) => {
							const ownedCount = counts.get(champ.id) ?? 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-border last:border-b-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										addCatalog(champ.id);
										setQuery("");
									},
									className: "flex min-h-14 w-full items-center gap-3 px-3 py-2 text-left",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-3 shrink-0 rounded-full ${affinityClass(champ.affinity)}` }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate font-medium",
												children: champ.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block text-xs text-muted",
												children: [
													champ.rarity,
													" · ",
													champ.role,
													" · ",
													champ.affinity
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-gold",
											children: ownedCount > 0 ? `Add another (${ownedCount})` : "Add"
										})
									]
								})
							}, champ.id);
						})
					}) : null,
					query && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Nothing under that name. Add them as a custom champion and tick the roles they actually bring."
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setCustomOpen((open) => !open),
				className: "flex h-11 items-center gap-2 self-start text-sm font-medium text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), customOpen ? "Close custom champion" : "Champion not in the list"]
			}),
			customOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomForm, { onDone: () => setCustomOpen(false) }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Your vault"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: loadSample,
							className: "h-11 rounded-md px-3 text-sm text-gold",
							children: owned.length === 0 ? "Load a sample vault" : "Add sample"
						}), owned.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (!confirmClear) {
									setConfirmClear(true);
									return;
								}
								clear();
								setConfirmClear(false);
							},
							className: "h-11 rounded-md px-3 text-sm text-muted",
							children: confirmClear ? "Confirm clear" : "Clear"
						}) : null]
					})]
				}), owned.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-dashed border-border bg-surface px-4 py-8 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: "The vault is empty."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Search a champion above, or load a sample clan-boss vault to see how the teams come out."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: owned.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultRow, { row }, row.uid))
				})]
			})
		]
	});
}
function VaultRow({ row }) {
	const remove = useRoster((s) => s.remove);
	const setSpeed = useRoster((s) => s.setSpeed);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "overflow-hidden rounded-lg border border-border bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-1.5 shrink-0 ${affinityClass(row.champ.affinity)}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setOpen((value) => !value),
							className: "min-w-0 flex-1 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-medium",
								children: row.champ.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-xs text-muted",
								children: [
									row.champ.rarity,
									" · ",
									row.champ.role,
									" · ",
									row.champ.faction
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => remove(row.uid),
							"aria-label": `Remove ${row.champ.name}`,
							className: "flex size-11 items-center justify-center text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreTrio, { champ: row.champ }),
					open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearBlock, {
						champ: row.champ,
						speed: row.speed,
						onSpeed: (speed) => setSpeed(row.uid, speed)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen((value) => !value),
						className: "mt-2 text-xs font-medium text-gold",
						children: open ? "Hide gear" : "Gear and speed"
					})
				]
			})]
		})
	});
}
function ScoreTrio({ champ }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
		className: "mt-2 grid grid-cols-3 gap-2 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
				label: "Demon",
				value: champ.scores.demon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
				label: "Hydra",
				value: champ.scores.hydra
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
				label: "Chimera",
				value: champ.scores.chimera
			})
		]
	});
}
function Score({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-faint",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 h-1.5 overflow-hidden rounded-full bg-raised",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block h-full rounded-full bg-primary",
				style: { width: `${value}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 tabular-nums text-muted",
			children: value
		})
	] });
}
function GearBlock({ champ, speed, onSpeed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-col gap-3 border-t border-border pt-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: champ.blurb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Speed"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					inputMode: "numeric",
					value: speed ?? "",
					placeholder: "—",
					onChange: (event) => {
						const raw = event.target.value.replace(/[^\d]/g, "");
						if (!raw) {
							onSpeed(null);
							return;
						}
						onSpeed(Math.min(400, Number(raw)));
					},
					className: "h-11 w-24 rounded-md border border-border bg-bg px-3 text-right tabular-nums"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearLines, { gear: champ.gear })
		]
	});
}
function GearLines({ gear, compact = false }) {
	const rows = [
		["Sets", gear.sets],
		["Stats", gear.stats],
		["Accuracy", gear.acc],
		["Masteries", gear.masteries],
		["Blessing", gear.blessing]
	];
	const visible = compact ? rows.slice(0, 2) : rows;
	const extra = compact ? rows.slice(2) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "flex flex-col gap-3",
			children: visible.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs font-medium tracking-wide text-gold uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "mt-1 text-sm text-fg",
				children: value
			})] }, label))
		}), extra.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "cursor-pointer text-sm font-medium text-gold",
			children: "Accuracy, masteries, blessing"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-3 flex flex-col gap-3",
			children: extra.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs font-medium tracking-wide text-gold uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "mt-1 text-sm text-fg",
				children: value
			})] }, label))
		})] }) : null]
	});
}
function CustomForm({ onDone }) {
	const addCustom = useRoster((s) => s.addCustom);
	const [name, setName] = (0, import_react.useState)("");
	const [rarity, setRarity] = (0, import_react.useState)("Legendary");
	const [affinity, setAffinity] = (0, import_react.useState)("Void");
	const [role, setRole] = (0, import_react.useState)("Support");
	const [tags, setTags] = (0, import_react.useState)([]);
	function toggle(tag) {
		setTags((current) => current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-4 rounded-lg border border-border bg-surface p-4",
		onSubmit: (event) => {
			event.preventDefault();
			if (!name.trim() || tags.length === 0) return;
			addCustom({
				name,
				affinity,
				rarity,
				role,
				tags
			});
			onDone();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg",
				children: "Custom champion"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (event) => setName(event.target.value),
					maxLength: 40,
					className: "h-12 rounded-md border border-border bg-bg px-3"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipPick, {
				label: "Rarity",
				value: rarity,
				options: RARITY_OPTIONS,
				onChange: setRarity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipPick, {
				label: "Affinity",
				value: affinity,
				options: AFFINITIES,
				onChange: setAffinity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipPick, {
				label: "Type",
				value: role,
				options: ROLES,
				onChange: setRole
			}),
			TAG_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "mb-2 text-sm text-muted",
				children: group.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: group.tags.map((tag) => {
					const on = tags.includes(tag);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": on,
						onClick: () => toggle(tag),
						className: `h-11 rounded-full border px-3 text-sm ${on ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`,
						children: tagLabel(tag)
					}, tag);
				})
			})] }, group.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: !name.trim() || tags.length === 0,
				className: "h-12 rounded-md bg-primary font-medium text-primary-fg disabled:opacity-40",
				children: "Add to vault"
			}),
			tags.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: "Tick at least one role so the team builder knows what they do."
			}) : null
		]
	});
}
function ChipPick({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "mb-2 text-sm text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": value === option,
			onClick: () => onChange(option),
			className: `h-11 rounded-full border px-3 text-sm ${value === option ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`,
			children: option
		}, option))
	})] });
}
function Teams({ owned, affinity }) {
	const [boss, setBoss] = (0, import_react.useState)("demon");
	const [hydraKey, setHydraKey] = (0, import_react.useState)(0);
	const setAffinity = useRoster((s) => s.setAffinity);
	const plan = (0, import_react.useMemo)(() => boss === "hydra" ? null : buildTeam(owned, boss, affinity[boss]), [
		owned,
		boss,
		affinity
	]);
	const hydra = (0, import_react.useMemo)(() => boss === "hydra" ? buildHydraKeys(owned, affinity.hydra) : [], [
		owned,
		boss,
		affinity.hydra
	]);
	const active = boss === "hydra" ? hydra[hydraKey] ?? null : plan;
	const meta = BOSS_META[boss];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				role: "tablist",
				"aria-label": "Boss",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BossTab, {
						active: boss === "demon",
						onClick: () => setBoss("demon"),
						label: "Demon Lord",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BossTab, {
						active: boss === "hydra",
						onClick: () => setBoss("hydra"),
						label: "Hydra",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BossTab, {
						active: boss === "chimera",
						onClick: () => setBoss("chimera"),
						label: "Chimera",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: meta.keys
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "mb-2 text-sm text-muted",
				children: boss === "hydra" ? "Head affinity to focus" : "Boss affinity today"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: (boss === "hydra" ? ["Any", ...AFFINITIES] : AFFINITIES).map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": affinity[boss] === option,
					onClick: () => setAffinity(boss, option),
					className: `h-11 rounded-full border px-3 text-sm ${affinity[boss] === option ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`,
					children: option === "Any" ? "Mixed heads" : option
				}, option))
			})] }),
			owned.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-dashed border-border bg-surface px-4 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg",
					children: "Add champions first."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "The vault is empty, so there is no team to forge."
				})]
			}) : null,
			boss === "hydra" && hydra.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: hydra.map((keyPlan, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": hydraKey === index,
					onClick: () => setHydraKey(index),
					className: `h-11 rounded-md border text-sm ${hydraKey === index ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`,
					children: [
						"Key ",
						index + 1,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs opacity-80",
							children: [keyPlan.members.length, "/6"]
						})
					]
				}, index))
			}) : null,
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamView, {
				plan: active,
				expected: meta.size,
				speedsKnown: active.turnOrder.every((m) => (m.speed ?? 0) > 0)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer font-medium",
					children: "Stat targets"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex list-disc flex-col gap-2 pl-5 text-sm text-muted",
					children: meta.targets.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
				})]
			})
		]
	});
}
function BossTab({ active, onClick, label, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "tab",
		"aria-selected": active,
		onClick,
		className: `flex h-14 flex-col items-center justify-center gap-1 rounded-md border text-xs font-medium ${active ? "border-primary bg-raised text-fg" : "border-border text-muted"}`,
		children: [icon, label]
	});
}
function TeamView({ plan, expected, speedsKnown }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-gold uppercase",
					children: plan.archetype
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl",
					children: ["Best to worst", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [
							" · ",
							plan.members.length,
							" of ",
							expected
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: plan.note
				}),
				plan.runnerUp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-gold",
					children: plan.runnerUp.note
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-2",
				children: plan.coverage.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: `rounded-full border px-3 py-1 text-xs ${item.met ? "border-primary text-primary" : "border-border text-faint"}`,
					children: [
						item.met ? "Ready" : "Missing",
						" · ",
						item.label
					]
				}, item.id))
			}),
			plan.warnings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2 rounded-lg border border-border bg-raised p-3 text-sm",
				children: plan.warnings.map((warning) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: warning }, warning))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-3",
				children: plan.members.map((member, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "overflow-hidden rounded-lg border border-border bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-1.5 shrink-0 ${affinityClass(member.owned.champ.affinity)}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-faint",
										children: ["#", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: `text-xs ${affinityText(member.owned.champ.affinity)}`,
										children: [member.owned.champ.affinity, member.weak ? " · weak hit" : ""]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl leading-tight",
									children: member.owned.champ.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										member.owned.champ.rarity,
										" · ",
										member.owned.champ.role,
										member.owned.speed ? ` · ${member.owned.speed} speed` : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm",
									children: member.why
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-faint",
									children: member.owned.champ.blurb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearLines, {
										gear: member.owned.champ.gear,
										compact: true
									})
								})
							]
						})]
					})
				}, member.owned.uid))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg",
					children: speedsKnown ? "Turn order by your speeds" : "Suggested open"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: speedsKnown ? "Fastest first. Ties of 1 speed can flip on the in-game roll." : "A role order, not a tune. Add speeds on each champion in the vault and this becomes a real turn order. Unkillable comps ignore this and follow the published speeds."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 flex flex-col gap-2",
					children: plan.turnOrder.map((member, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-8 items-center justify-center rounded-full bg-raised text-xs tabular-nums text-gold",
								children: index + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: member.champ.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted tabular-nums",
								children: member.speed ? member.speed : tagHint(member.champ)
							})
						]
					}, member.uid))
				})
			] }),
			plan.suggestions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-lg",
				children: "Worth building next"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-2",
				children: plan.suggestions.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-md border border-border px-3 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: row.champ.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [
							" · ",
							row.champ.rarity,
							" · ",
							row.reason
						]
					})]
				}, row.champ.id))
			})] }) : null
		]
	});
}
function tagHint(champ) {
	if (champ.tags.includes("speed-aura") || champ.tags.includes("tm-boost")) return "Lead";
	if (champ.tags.includes("unkillable") || champ.tags.includes("block-damage")) return "Tune";
	if (champ.tags.includes("dec-atk") || champ.tags.includes("ally-protect")) return "Early";
	if (champ.tags.includes("dec-def") || champ.tags.includes("weaken")) return "Debuff";
	return "Damage";
}
function Ranks({ owned }) {
	const [key, setKey] = (0, import_react.useState)("overall");
	const [rarity, setRarity] = (0, import_react.useState)("All");
	const ranked = rankRoster(owned, key).filter((row) => rarity === "All" || row.champ.rarity === rarity);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Best to worst"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Overall is an even split of Demon Lord, Hydra, and Chimera. A specialist can rank lower overall and still be the right pick on one boss."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"overall",
					"demon",
					"hydra",
					"chimera"
				].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": key === option,
					onClick: () => setKey(option),
					className: `h-11 rounded-full border px-3 text-sm ${key === option ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`,
					children: option === "overall" ? "Overall" : option === "demon" ? "Demon Lord" : option === "hydra" ? "Hydra" : "Chimera"
				}, option))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: ["All", ...RARITY_OPTIONS].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": rarity === option,
					onClick: () => setRarity(option),
					className: `h-11 rounded-full border px-3 text-sm ${rarity === option ? "border-gold text-gold" : "border-border text-muted"}`,
					children: option === "All" ? "All rarities" : option
				}, option))
			}),
			ranked.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-dashed border-border px-4 py-8 text-center text-sm text-muted",
				children: "Nothing in the vault for this filter."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-2",
				children: ranked.map((row, index) => {
					const score = bossScore(row.champ, key);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-border bg-surface p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-6 text-sm text-gold tabular-nums",
										children: index + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate font-medium",
											children: row.champ.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted",
											children: [
												row.champ.rarity,
												" · ",
												row.champ.affinity,
												" · ",
												row.champ.role
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-lg tabular-nums text-fg",
										children: score
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 ml-9 h-1.5 overflow-hidden rounded-full bg-raised",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block h-full rounded-full bg-primary",
									style: { width: `${score}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 ml-9 text-xs text-muted",
								children: row.champ.gear.sets
							})
						]
					}, row.uid);
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AshenApp, {});
}
//#endregion
export { Home as component };
