import { create } from "zustand";
import { persist } from "zustand/middleware";
import { SAMPLE_IDS, championById, type Affinity, type Champion, type Rarity, type Role } from "@/data/champions";
import { gearForTags, scoresFromTags, type BossAffinity } from "@/lib/optimizer";

export interface RosterEntry {
  uid: string;
  championId: string;
  speed: number | null;
}

interface RosterState {
  entries: RosterEntry[];
  customs: Champion[];
  affinity: Record<"demon" | "hydra" | "chimera", BossAffinity>;
  addCatalog: (id: string) => void;
  addCustom: (draft: { name: string; affinity: Affinity; rarity: Rarity; role: Role; tags: string[] }) => void;
  remove: (uid: string) => void;
  setSpeed: (uid: string, speed: number | null) => void;
  setAffinity: (boss: "demon" | "hydra" | "chimera", affinity: BossAffinity) => void;
  loadSample: () => void;
  clear: () => void;
}

function uid(): string {
  return crypto.randomUUID();
}

export const useRoster = create<RosterState>()(
  persist(
    (set, get) => ({
      entries: [],
      customs: [],
      affinity: { demon: "Void", hydra: "Any", chimera: "Void" },
      addCatalog: (id) => {
        if (!championById(id)) return;
        if (get().entries.length >= 60) return;
        set({ entries: [...get().entries, { uid: uid(), championId: id, speed: null }] });
      },
      addCustom: (draft) => {
        if (get().entries.length >= 60) return;
        const name = draft.name.trim().slice(0, 40);
        if (!name) return;
        const id = `custom-${uid()}`;
        const tags = draft.tags;
        const champ: Champion = {
          id,
          name,
          faction: "Your vault",
          affinity: draft.affinity,
          rarity: draft.rarity,
          role: draft.role,
          scores: scoresFromTags(tags),
          tags,
          gear: gearForTags(tags, draft.role),
          blurb: "Custom champion. Ratings come from the roles you toggled, not a tested kit.",
        };
        set({
          customs: [...get().customs, champ],
          entries: [...get().entries, { uid: uid(), championId: id, speed: null }],
        });
      },
      remove: (id) => {
        const entry = get().entries.find((row) => row.uid === id);
        set({
          entries: get().entries.filter((row) => row.uid !== id),
          customs: entry?.championId.startsWith("custom-")
            ? get().customs.filter((champ) => champ.id !== entry.championId)
            : get().customs,
        });
      },
      setSpeed: (id, speed) => {
        set({
          entries: get().entries.map((row) => (row.uid === id ? { ...row, speed } : row)),
        });
      },
      setAffinity: (boss, affinity) => set({ affinity: { ...get().affinity, [boss]: affinity } }),
      loadSample: () => {
        const have = new Set(get().entries.map((row) => row.championId));
        const next = [...get().entries];
        for (const id of SAMPLE_IDS) {
          if (have.has(id) || next.length >= 60) continue;
          next.push({ uid: uid(), championId: id, speed: null });
        }
        set({ entries: next });
      },
      clear: () => set({ entries: [], customs: [] }),
    }),
    {
      name: "ashen-keys-vault",
      skipHydration: true,
    },
  ),
);

export function resolveOwned(entries: RosterEntry[], customs: Champion[]) {
  const customMap = new Map(customs.map((champ) => [champ.id, champ]));
  const owned = [];
  for (const entry of entries) {
    const champ = championById(entry.championId) ?? customMap.get(entry.championId);
    if (!champ) continue;
    owned.push({ uid: entry.uid, champ, speed: entry.speed });
  }
  return owned;
}
