import type { Affinity, BossId, Champion, Rarity, Role } from "@/data/champions";
import { CHAMPIONS, overallScore } from "@/data/champions";
import { GEAR, type Gear } from "@/data/gear";
import { tagLabel } from "@/data/tags";

export type BossAffinity = Affinity | "Any";

export interface Owned {
  uid: string;
  champ: Champion;
  speed: number | null;
}

export interface CoverageItem {
  id: string;
  label: string;
  met: boolean;
}

export interface TeamMember {
  owned: Owned;
  contribution: number;
  why: string;
  weak: boolean;
}

export interface TeamPlan {
  boss: BossId;
  archetypeId: string;
  archetype: string;
  note: string;
  members: TeamMember[];
  coverage: CoverageItem[];
  turnOrder: Owned[];
  suggestions: { champ: Champion; reason: string }[];
  warnings: string[];
  runnerUp?: { archetype: string; note: string };
  score: number;
}

interface Weight {
  tag: string;
  first: number;
  extra: number;
  cap?: number;
}

interface Archetype {
  id: string;
  label: string;
  note: string;
  weights: Weight[];
  enabled: (roster: Owned[]) => boolean;
}

const DAMAGE = ["poison", "hp-burn", "enemy-max-hp", "boss-dmg"];

const DEMON_TRAD: Weight[] = [
  { tag: "dec-def", first: 36, extra: 4 },
  { tag: "weaken", first: 28, extra: 3 },
  { tag: "dec-atk", first: 32, extra: 4 },
  { tag: "poison", first: 22, extra: 12, cap: 3 },
  { tag: "poison-sens", first: 18, extra: 2 },
  { tag: "hp-burn", first: 22, extra: 4 },
  { tag: "enemy-max-hp", first: 30, extra: 12 },
  { tag: "boss-dmg", first: 14, extra: 4 },
  { tag: "ally-protect", first: 26, extra: 6 },
  { tag: "counter", first: 18, extra: 2 },
  { tag: "leech", first: 14, extra: 1 },
  { tag: "cleanse", first: 16, extra: 3 },
  { tag: "block-debuffs", first: 16, extra: 2 },
  { tag: "heal", first: 10, extra: 2 },
  { tag: "cont-heal", first: 6, extra: 2 },
  { tag: "shield", first: 10, extra: 4 },
  { tag: "inc-def", first: 8, extra: 2 },
  { tag: "strengthen", first: 8, extra: 1 },
  { tag: "extend-debuff", first: 26, extra: 2 },
  { tag: "extend-buff", first: 12, extra: 2 },
  { tag: "ally-attack", first: 18, extra: 4 },
  { tag: "reflect", first: 16, extra: 2 },
  { tag: "speed-aura", first: 6, extra: 0 },
  { tag: "def-aura", first: 4, extra: 0 },
];

const DEMON_UK: Weight[] = [
  { tag: "unkillable", first: 40, extra: 22 },
  { tag: "block-damage", first: 40, extra: 18 },
  { tag: "cooldown-reduce", first: 28, extra: 8 },
  { tag: "tm-boost", first: 14, extra: 2 },
  { tag: "cleanse", first: 14, extra: 2 },
  { tag: "block-debuffs", first: 12, extra: 2 },
  { tag: "dec-def", first: 30, extra: 3 },
  { tag: "weaken", first: 26, extra: 2 },
  { tag: "dec-atk", first: 14, extra: 2 },
  { tag: "poison", first: 20, extra: 10, cap: 3 },
  { tag: "poison-sens", first: 16, extra: 2 },
  { tag: "hp-burn", first: 20, extra: 4 },
  { tag: "enemy-max-hp", first: 28, extra: 10 },
  { tag: "boss-dmg", first: 12, extra: 4 },
  { tag: "ally-attack", first: 14, extra: 3 },
  { tag: "extend-debuff", first: 22, extra: 2 },
  { tag: "reflect", first: 12, extra: 2 },
  { tag: "leech", first: 6, extra: 0 },
];

const DEMON_SHIELD: Weight[] = [
  { tag: "shield-grow", first: 48, extra: 4 },
  { tag: "shield", first: 28, extra: 16 },
  { tag: "reflect", first: 18, extra: 6 },
  { tag: "inc-def", first: 12, extra: 3 },
  { tag: "strengthen", first: 10, extra: 2 },
  { tag: "extend-buff", first: 14, extra: 3 },
  { tag: "enemy-max-hp", first: 32, extra: 8 },
  { tag: "boss-dmg", first: 14, extra: 4 },
  { tag: "hp-burn", first: 16, extra: 4 },
  { tag: "poison", first: 12, extra: 4 },
  { tag: "dec-def", first: 22, extra: 3 },
  { tag: "weaken", first: 20, extra: 2 },
  { tag: "dec-atk", first: 12, extra: 2 },
  { tag: "counter", first: 8, extra: 2 },
  { tag: "ally-attack", first: 10, extra: 2 },
];

const HYDRA: Weight[] = [
  { tag: "provoke", first: 40, extra: 6 },
  { tag: "block-buffs", first: 38, extra: 4 },
  { tag: "dec-def", first: 26, extra: 4 },
  { tag: "weaken", first: 20, extra: 3 },
  { tag: "hp-burn", first: 26, extra: 14, cap: 3 },
  { tag: "hex", first: 18, extra: 3 },
  { tag: "enemy-max-hp", first: 22, extra: 8 },
  { tag: "poison", first: 10, extra: 4 },
  { tag: "cleanse", first: 22, extra: 4 },
  { tag: "fear-cleanse", first: 24, extra: 2 },
  { tag: "block-debuffs", first: 16, extra: 3 },
  { tag: "revive", first: 14, extra: 3 },
  { tag: "heal", first: 12, extra: 3 },
  { tag: "leech", first: 12, extra: 2 },
  { tag: "dec-spd", first: 12, extra: 3 },
  { tag: "dec-atk", first: 12, extra: 3 },
  { tag: "inc-spd", first: 10, extra: 2 },
  { tag: "tm-boost", first: 10, extra: 2 },
  { tag: "shield", first: 10, extra: 4 },
  { tag: "ally-protect", first: 8, extra: 2 },
  { tag: "speed-aura", first: 8, extra: 0 },
  { tag: "perfect-veil", first: -6, extra: -4 },
  { tag: "veil", first: -4, extra: -2 },
];

const CHIMERA: Weight[] = [
  { tag: "dec-def", first: 32, extra: 4 },
  { tag: "weaken", first: 28, extra: 3 },
  { tag: "dec-spd", first: 16, extra: 3 },
  { tag: "dec-atk", first: 14, extra: 3 },
  { tag: "dec-res", first: 10, extra: 2 },
  { tag: "leech", first: 12, extra: 1 },
  { tag: "heal", first: 20, extra: 4 },
  { tag: "cont-heal", first: 14, extra: 3 },
  { tag: "revive", first: 22, extra: 4 },
  { tag: "cleanse", first: 20, extra: 4 },
  { tag: "block-debuffs", first: 16, extra: 3 },
  { tag: "shield", first: 22, extra: 10 },
  { tag: "shield-grow", first: 26, extra: 4 },
  { tag: "inc-def", first: 12, extra: 3 },
  { tag: "inc-atk", first: 10, extra: 2 },
  { tag: "inc-spd", first: 8, extra: 2 },
  { tag: "strengthen", first: 10, extra: 2 },
  { tag: "ally-protect", first: 12, extra: 3 },
  { tag: "hp-burn", first: 14, extra: 4 },
  { tag: "poison", first: 12, extra: 4 },
  { tag: "enemy-max-hp", first: 26, extra: 8 },
  { tag: "boss-dmg", first: 16, extra: 4 },
  { tag: "block-damage", first: 4, extra: 0 },
  { tag: "unkillable", first: 2, extra: 0 },
  { tag: "hex", first: 8, extra: 2 },
  { tag: "buff-strip", first: 6, extra: 1 },
];

function countTag(roster: Owned[], tag: string): number {
  return roster.filter((o) => o.champ.tags.includes(tag)).length;
}

const ARCHETYPES: Record<BossId, Archetype[]> = {
  demon: [
    {
      id: "shield",
      label: "Shield growth",
      note: "Wixwell grows the shield every turn. Pair him with another shielder and a defense-based nuker. Speeds still have to be tuned, but the team does not rely on Unkillable.",
      weights: DEMON_SHIELD,
      enabled: (roster) => countTag(roster, "shield-grow") >= 1 && (countTag(roster, "shield") >= 2 || countTag(roster, "reflect") >= 1),
    },
    {
      id: "unkillable",
      label: "Unkillable tune",
      note: "Block Damage or Unkillable on a fixed speed tune. This is the most reliable Ultra-Nightmare plan if the speeds are exact. It is a poor Chimera plan, and Lion ignores both buffs.",
      weights: DEMON_UK,
      enabled: (roster) => {
        const uk = countTag(roster, "unkillable");
        const bd = countTag(roster, "block-damage");
        const cd = countTag(roster, "cooldown-reduce");
        return uk >= 2 || bd >= 2 || (uk >= 1 && bd >= 1) || (bd >= 1 && cd >= 1) || (uk >= 1 && cd >= 1);
      },
    },
    {
      id: "classic",
      label: "Classic survival",
      note: "Decrease ATK, ally protect or a counterattack, then poisons or burns. Works from Nightmare upward. Someone needs Leech, or the damage dealers wear Lifesteal.",
      weights: DEMON_TRAD,
      enabled: () => true,
    },
  ],
  hydra: [
    {
      id: "heads",
      label: "Head control",
      note: "Six champions. Provoke so Mischief cannot eat your buffs, and Block Buffs so Suffering cannot cleanse you. Burns land per head, so more than one burner is useful. You cannot reuse a champion on another Hydra key this week.",
      weights: HYDRA,
      enabled: () => true,
    },
  ],
  chimera: [
    {
      id: "forms",
      label: "Form control",
      note: "Five champions across 65 turns and four forms. Keep buffs up — the Ultimate form punishes an unbuffed team. Bring a cleanse for Viper and a revive for Necrosis. Do not trust Unkillable or Block Damage: Lion ignores both.",
      weights: CHIMERA,
      enabled: () => true,
    },
  ],
};

export const TEAM_SIZE: Record<BossId, number> = {
  demon: 5,
  hydra: 6,
  chimera: 5,
};

export const BOSS_META: Record<
  BossId,
  { name: string; size: number; keys: string; targets: string[] }
> = {
  demon: {
    name: "Demon Lord",
    size: 5,
    keys: "One team, up to four keys a day. The same five usually run every key.",
    targets: [
      "Accuracy 250 on Ultra-Nightmare for anyone landing a debuff.",
      "About 3,500 DEF and 40,000 HP if you are not in an unkillable tune.",
      "Speed is the tune, not a vibe. 171–189 is a common 1:1 range. 2:1 wants 251+. Unkillable comps use exact speeds.",
    ],
  },
  hydra: {
    name: "Hydra",
    size: 6,
    keys: "Three keys. Champions lock for the week — each key needs a different six.",
    targets: [
      "Nightmare accuracy is about 350. Lower difficulties ask for less.",
      "Provoke for Mischief. Block Buffs for Suffering. A fear cleanse for Torment.",
      "HP Burn is the damage engine. One burn per head, not three burns on one head.",
    ],
  },
  chimera: {
    name: "Chimera",
    size: 5,
    keys: "Five champions, exactly 65 turns, two keys. The same five can run both keys.",
    targets: [
      "Accuracy about 25 over the boss resistance for that difficulty.",
      "Buff uptime matters: Increase DEF, shields, Block Debuffs, heals.",
      "Ram reflects. Viper poisons. Lion ignores Unkillable and Block Damage. Ultimate wants your team buffed.",
    ],
  },
};

const COVERAGE: Record<BossId, { id: string; label: string; tags: string[] }[]> = {
  demon: [
    { id: "def", label: "Decrease DEF", tags: ["dec-def"] },
    { id: "weak", label: "Weaken", tags: ["weaken"] },
    { id: "atk", label: "Decrease ATK", tags: ["dec-atk"] },
    { id: "dmg", label: "Poison, burn, or max HP", tags: DAMAGE },
    { id: "live", label: "Protect or unkillable", tags: ["ally-protect", "unkillable", "block-damage", "counter", "shield-grow"] },
    { id: "safe", label: "Cleanse, leech, or shields", tags: ["cleanse", "block-debuffs", "leech", "shield-grow"] },
  ],
  hydra: [
    { id: "prov", label: "Provoke", tags: ["provoke"] },
    { id: "block", label: "Block buffs", tags: ["block-buffs"] },
    { id: "def", label: "Decrease DEF", tags: ["dec-def"] },
    { id: "burn", label: "HP Burn", tags: ["hp-burn"] },
    { id: "clean", label: "Cleanse", tags: ["cleanse", "block-debuffs", "fear-cleanse"] },
    { id: "hex", label: "Hex or Weaken", tags: ["hex", "weaken"] },
  ],
  chimera: [
    { id: "def", label: "Decrease DEF", tags: ["dec-def"] },
    { id: "weak", label: "Weaken", tags: ["weaken"] },
    { id: "heal", label: "Heal", tags: ["heal", "cont-heal", "leech"] },
    { id: "clean", label: "Cleanse", tags: ["cleanse", "block-debuffs"] },
    { id: "rev", label: "Revive", tags: ["revive"] },
    { id: "shield", label: "Shield or strengthen", tags: ["shield", "strengthen", "inc-def"] },
  ],
};

function tagCounts(team: Owned[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const member of team) {
    const seen = new Set<string>();
    for (const tag of member.champ.tags) {
      if (seen.has(tag)) continue;
      seen.add(tag);
      counts[tag] = (counts[tag] ?? 0) + 1;
    }
  }
  return counts;
}

const WEAK_AGAINST: Record<Affinity, Affinity | null> = {
  Magic: "Force",
  Force: "Spirit",
  Spirit: "Magic",
  Void: null,
};

const STRONG_AGAINST: Record<Affinity, Affinity | null> = {
  Magic: "Spirit",
  Force: "Magic",
  Spirit: "Force",
  Void: null,
};

export function affinityWord(champ: Affinity, boss: BossAffinity): "weak" | "strong" | "neutral" {
  if (boss === "Any" || champ === "Void") return "neutral";
  if (WEAK_AGAINST[champ] === boss) return "weak";
  if (STRONG_AGAINST[champ] === boss) return "strong";
  return "neutral";
}

function affinityScore(team: Owned[], boss: BossId, affinity: BossAffinity): number {
  let score = 0;
  if (boss === "hydra" && affinity === "Any") {
    const kinds = new Set(team.map((m) => m.champ.affinity).filter((a) => a !== "Void"));
    score += Math.min(3, kinds.size) * 4;
    if (team.some((m) => m.champ.affinity === "Void")) score += 6;
    return score;
  }
  for (const member of team) {
    const word = affinityWord(member.champ.affinity, affinity);
    if (word === "weak") score -= 18;
    else if (word === "strong") score += 6;
    else if (member.champ.affinity === "Void" && affinity !== "Any") score += 4;
  }
  return score;
}

function synergy(counts: Record<string, number>, boss: BossId, archetypeId: string): number {
  let score = 0;
  if (counts["dec-def"] && counts["weaken"]) score += 12;
  if (counts["poison"] && counts["poison-sens"]) score += 16;
  if (counts["unkillable"] && counts["cooldown-reduce"]) score += 20;
  if (counts["block-damage"] && counts["cooldown-reduce"]) score += 20;
  if (counts["block-damage"] && counts["tm-boost"]) score += 8;
  if ((counts["shield-grow"] ?? 0) >= 1 && (counts["shield"] ?? 0) >= 2) score += 30;
  if (counts["shield-grow"] && counts["reflect"] && counts["enemy-max-hp"]) score += 42;
  if (counts["hp-burn"] && counts["ally-attack"]) score += 8;
  if (counts["poison"] && counts["extend-debuff"]) score += 18;
  if (boss === "hydra" && counts["provoke"] && counts["block-buffs"]) score += 16;
  if (boss === "chimera" && counts["revive"] && counts["cleanse"]) score += 10;
  if (boss === "demon" && archetypeId === "unkillable") {
    const protectors = (counts["unkillable"] ?? 0) + (counts["block-damage"] ?? 0);
    if (protectors < 1) score -= 30;
  }
  const damage =
    (counts["poison"] ?? 0) +
    (counts["hp-burn"] ?? 0) +
    (counts["enemy-max-hp"] ?? 0) +
    (counts["boss-dmg"] ?? 0) +
    (counts["reflect"] ?? 0);
  if (damage > 0) score += 12;
  return score;
}

function teamScore(team: Owned[], boss: BossId, affinity: BossAffinity, weights: Weight[], archetypeId: string): number {
  let score = 0;
  for (const member of team) score += member.champ.scores[boss];
  const counts = tagCounts(team);
  for (const weight of weights) {
    const n = Math.min(counts[weight.tag] ?? 0, weight.cap ?? 6);
    if (n <= 0) continue;
    score += weight.first + weight.extra * (n - 1);
  }
  score += synergy(counts, boss, archetypeId);
  score += affinityScore(team, boss, affinity);
  return score;
}

function optimizeArchetype(roster: Owned[], boss: BossId, affinity: BossAffinity, archetype: Archetype): Owned[] {
  const size = Math.min(TEAM_SIZE[boss], roster.length);
  if (size === 0) return [];
  let beam: Owned[][] = [[]];
  const width = 24;
  for (let slot = 0; slot < size; slot += 1) {
    const next: { team: Owned[]; score: number }[] = [];
    for (const partial of beam) {
      const used = new Set(partial.map((m) => m.uid));
      for (const candidate of roster) {
        if (used.has(candidate.uid)) continue;
        const team = [...partial, candidate];
        next.push({
          team,
          score: teamScore(team, boss, affinity, archetype.weights, archetype.id),
        });
      }
    }
    next.sort((a, b) => b.score - a.score);
    const seen = new Set<string>();
    beam = [];
    for (const row of next) {
      const key = row.team
        .map((m) => m.uid)
        .sort()
        .join(":");
      if (seen.has(key)) continue;
      seen.add(key);
      beam.push(row.team);
      if (beam.length >= width) break;
    }
  }
  let best = beam
    .map((team) => ({ team, score: teamScore(team, boss, affinity, archetype.weights, archetype.id) }))
    .sort((a, b) => b.score - a.score)[0]?.team ?? [];

  let improved = true;
  let guard = 0;
  while (improved && guard < 6) {
    improved = false;
    guard += 1;
    const base = teamScore(best, boss, affinity, archetype.weights, archetype.id);
    for (let i = 0; i < best.length; i += 1) {
      for (const candidate of roster) {
        if (best.some((m) => m.uid === candidate.uid)) continue;
        const trial = best.slice();
        trial[i] = candidate;
        const next = teamScore(trial, boss, affinity, archetype.weights, archetype.id);
        if (next > base + 0.5) {
          best = trial;
          improved = true;
          break;
        }
      }
      if (improved) break;
    }
  }
  return best;
}

function whyFor(member: Owned, team: Owned[], boss: BossId): string {
  const counts = tagCounts(team);
  const important = new Set(COVERAGE[boss].flatMap((item) => item.tags).concat(
    boss === "demon" ? ["shield-grow", "unkillable", "block-damage", "extend-debuff", "ally-attack", "enemy-max-hp"] : [],
  ));
  const unique = member.champ.tags.filter((tag) => important.has(tag) && counts[tag] === 1);
  const shared = member.champ.tags.filter((tag) => important.has(tag) && (counts[tag] ?? 0) > 1);
  if (unique.length > 0) {
    return `Only slot covering ${unique.map(tagLabel).join(", ")}.`;
  }
  if (shared.length > 0) {
    return `Backs up ${shared.slice(0, 3).map(tagLabel).join(", ")}.`;
  }
  return member.champ.blurb;
}

function warningsFor(team: Owned[], boss: BossId): string[] {
  const counts = tagCounts(team);
  const notes: string[] = [];
  if (boss === "hydra") {
    if (!counts["provoke"]) notes.push("No Provoke. Mischief will steal your buffs and throw them back.");
    if (!counts["block-buffs"]) notes.push("No Block Buffs. Suffering cleanses the debuffs you just landed.");
    if (!counts["fear-cleanse"]) notes.push("No fear cleanse. Torment will fear the team unless someone else handles it.");
  }
  if (boss === "chimera") {
    if ((counts["unkillable"] || counts["block-damage"]) && !counts["heal"] && !counts["shield"]) {
      notes.push("This team is leaning on Unkillable or Block Damage. Lion form ignores both.");
    }
    if (!counts["cleanse"] && !counts["block-debuffs"]) notes.push("No cleanse. Viper's poisons will sit for the whole form.");
    if (!counts["revive"]) notes.push("No revive. A dead champion feeds Necrosis.");
  }
  if (boss === "demon") {
    const damage = DAMAGE.some((tag) => counts[tag]) || counts["reflect"];
    if (!damage) notes.push("No poison, burn, or max-HP damage. The team will survive and do very little.");
    if (!counts["dec-def"]) notes.push("No Decrease DEF. Damage is roughly cut in half.");
    if (!counts["leech"] && !counts["unkillable"] && !counts["block-damage"] && !counts["shield-grow"]) {
      notes.push("No Leech and no unkillable plan. Put the damage dealers in Lifesteal, or add a Leech champion.");
    }
  }
  return notes;
}

function suggestionsFor(roster: Owned[], team: Owned[], boss: BossId): { champ: Champion; reason: string }[] {
  const ownedIds = new Set(roster.map((m) => m.champ.id));
  const counts = tagCounts(team);
  const missing = COVERAGE[boss].filter((item) => !item.tags.some((tag) => (counts[tag] ?? 0) > 0));
  const out: { champ: Champion; reason: string }[] = [];
  for (const gap of missing) {
    const pick = CHAMPIONS.filter((champ) => !ownedIds.has(champ.id) && champ.tags.some((tag) => gap.tags.includes(tag)))
      .sort((a, b) => b.scores[boss] - a.scores[boss])[0];
    if (pick && !out.some((row) => row.champ.id === pick.id)) {
      out.push({ champ: pick, reason: `Would cover ${gap.label}.` });
    }
  }
  return out.slice(0, 3);
}

function orderTurn(team: Owned[]): Owned[] {
  const speeds = team.every((m) => m.speed && m.speed > 0);
  if (speeds) return [...team].sort((a, b) => (b.speed ?? 0) - (a.speed ?? 0));
  const rank = (champ: Champion) => {
    const tags = new Set(champ.tags);
    if (tags.has("speed-aura") || tags.has("tm-boost") || tags.has("inc-spd")) return 1;
    if (tags.has("unkillable") || tags.has("block-damage") || tags.has("block-debuffs") || tags.has("shield-grow")) return 2;
    if (tags.has("dec-atk") || tags.has("ally-protect") || tags.has("provoke")) return 3;
    if (tags.has("dec-def") || tags.has("weaken") || tags.has("cleanse")) return 4;
    return 5;
  };
  return [...team].sort((a, b) => rank(a.champ) - rank(b.champ) || a.champ.name.localeCompare(b.champ.name));
}

function decorate(
  team: Owned[],
  roster: Owned[],
  boss: BossId,
  affinity: BossAffinity,
  archetype: Archetype,
  score: number,
): TeamPlan {
  const counts = tagCounts(team);
  const members = team
    .map((owned) => ({
      owned,
      contribution: 0,
      why: whyFor(owned, team, boss),
      weak: affinityWord(owned.champ.affinity, affinity) === "weak",
    }))
    .map((member) => {
      const without = team.filter((other) => other.uid !== member.owned.uid);
      const full = teamScore(team, boss, affinity, archetype.weights, archetype.id);
      const rest = teamScore(without, boss, affinity, archetype.weights, archetype.id);
      return { ...member, contribution: Math.max(0, Math.round(full - rest)) };
    })
    .sort((a, b) => b.contribution - a.contribution);

  return {
    boss,
    archetypeId: archetype.id,
    archetype: archetype.label,
    note: archetype.note,
    members,
    coverage: COVERAGE[boss].map((item) => ({
      id: item.id,
      label: item.label,
      met: item.tags.some((tag) => (counts[tag] ?? 0) > 0),
    })),
    turnOrder: orderTurn(team),
    suggestions: suggestionsFor(roster, team, boss),
    warnings: warningsFor(team, boss),
    score,
  };
}

export function buildTeam(roster: Owned[], boss: BossId, affinity: BossAffinity): TeamPlan | null {
  if (roster.length === 0) return null;
  const options = ARCHETYPES[boss].filter((archetype) => archetype.enabled(roster));
  const ranked = options
    .map((archetype) => {
      const team = optimizeArchetype(roster, boss, affinity, archetype);
      return {
        archetype,
        team,
        score: teamScore(team, boss, affinity, archetype.weights, archetype.id),
      };
    })
    .sort((a, b) => b.score - a.score);
  const best = ranked[0];
  if (!best) return null;
  const counts = tagCounts(best.team);
  let shown = best.archetype;
  if (
    boss === "demon" &&
    counts["shield-grow"] &&
    counts["reflect"] &&
    shown.id !== "shield"
  ) {
    shown = ARCHETYPES.demon.find((row) => row.id === "shield") ?? shown;
  }
  if (
    boss === "demon" &&
    ((counts["unkillable"] ?? 0) >= 2 || ((counts["unkillable"] ?? 0) >= 1 && (counts["block-damage"] ?? 0) >= 1) || ((counts["block-damage"] ?? 0) >= 1 && (counts["cooldown-reduce"] ?? 0) >= 1)) &&
    shown.id !== "unkillable"
  ) {
    shown = ARCHETYPES.demon.find((row) => row.id === "unkillable") ?? shown;
  }
  const plan = decorate(best.team, roster, boss, affinity, shown, best.score);
  const second = ranked[1];
  if (second && second.score >= best.score * 0.9 && second.archetype.id !== shown.id && second.archetype.id !== best.archetype.id) {
    plan.runnerUp = {
      archetype: second.archetype.label,
      note: `${second.archetype.label} is close. Use it if you cannot hit the speeds for ${shown.label}.`,
    };
  }
  return plan;
}

export function buildHydraKeys(roster: Owned[], affinity: BossAffinity): TeamPlan[] {
  const plans: TeamPlan[] = [];
  let pool = roster.slice();
  for (let key = 0; key < 3; key += 1) {
    if (pool.length === 0) break;
    const plan = buildTeam(pool, "hydra", affinity);
    if (!plan || plan.members.length === 0) break;
    plans.push(plan);
    const used = new Set(plan.members.map((m) => m.owned.uid));
    pool = pool.filter((m) => !used.has(m.uid));
  }
  return plans;
}

export function gearForTags(tags: string[], role: Role): Gear {
  if (tags.includes("unkillable") || (tags.includes("block-damage") && tags.includes("cooldown-reduce"))) return GEAR.unkillable;
  if (tags.includes("shield-grow")) return GEAR.shield;
  if (tags.includes("enemy-max-hp") && role === "Defense") return GEAR.nukerDef;
  if (tags.includes("enemy-max-hp") || tags.includes("boss-dmg")) return GEAR.nuker;
  if (tags.includes("ally-protect")) return GEAR.protector;
  if (tags.includes("hp-burn")) return GEAR.burn;
  if (tags.includes("poison") || tags.includes("poison-sens")) return GEAR.poison;
  if (tags.includes("dec-def") || tags.includes("weaken") || tags.includes("dec-atk") || tags.includes("block-buffs")) return GEAR.debuffer;
  return GEAR.support;
}

export function scoresFromTags(tags: string[]): Record<BossId, number> {
  const tables: Record<BossId, Record<string, number>> = {
    demon: {
      "dec-def": 14,
      weaken: 12,
      "dec-atk": 12,
      poison: 12,
      "poison-sens": 10,
      "hp-burn": 10,
      "enemy-max-hp": 16,
      "boss-dmg": 8,
      "ally-protect": 12,
      counter: 10,
      unkillable: 16,
      "block-damage": 16,
      "shield-grow": 16,
      leech: 6,
      cleanse: 8,
      "extend-debuff": 14,
      "ally-attack": 10,
      reflect: 10,
    },
    hydra: {
      provoke: 16,
      "block-buffs": 16,
      "dec-def": 10,
      weaken: 8,
      "hp-burn": 14,
      hex: 10,
      "enemy-max-hp": 12,
      cleanse: 10,
      "fear-cleanse": 14,
      revive: 6,
      leech: 6,
      "dec-spd": 6,
    },
    chimera: {
      "dec-def": 12,
      weaken: 12,
      heal: 10,
      "cont-heal": 8,
      revive: 12,
      cleanse: 10,
      "block-debuffs": 8,
      shield: 10,
      "shield-grow": 12,
      "enemy-max-hp": 14,
      "boss-dmg": 10,
      "inc-def": 6,
      strengthen: 6,
    },
  };
  const score = (boss: BossId) => {
    let value = 28;
    const seen = new Set<string>();
    for (const tag of tags) {
      if (seen.has(tag)) continue;
      seen.add(tag);
      value += tables[boss][tag] ?? 2;
    }
    return Math.max(20, Math.min(88, value));
  };
  return { demon: score("demon"), hydra: score("hydra"), chimera: score("chimera") };
}

export function rankRoster(roster: Owned[], boss: BossId | "overall"): Owned[] {
  return [...roster].sort((a, b) => {
    const as = boss === "overall" ? overallScore(a.champ) : a.champ.scores[boss];
    const bs = boss === "overall" ? overallScore(b.champ) : b.champ.scores[boss];
    return bs - as || a.champ.name.localeCompare(b.champ.name);
  });
}

export function bossScore(champ: Champion, boss: BossId | "overall"): number {
  return boss === "overall" ? overallScore(champ) : champ.scores[boss];
}

export const RARITIES: Rarity[] = ["Mythical", "Legendary", "Epic", "Rare"];
