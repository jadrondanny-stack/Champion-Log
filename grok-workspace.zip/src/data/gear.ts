export interface Gear {
  sets: string;
  stats: string;
  acc: string;
  masteries: string;
  blessing: string;
}

const ACC =
  "Debuffers want about 250 accuracy on Demon Lord Ultra-Nightmare (220 on Nightmare, 200 on Brutal). Hydra Nightmare is closer to 350. On Chimera, sit about 25 accuracy over that difficulty's resistance.";

const BRIM =
  "Put 5 or 6 star Brimstone on one champion only. A second debuffer should take Cruelty instead. Two Brimstones do not stack.";

export function gear(partial: Omit<Gear, "acc" | "blessing"> & Partial<Pick<Gear, "acc" | "blessing">>): Gear {
  return {
    acc: ACC,
    blessing: BRIM,
    ...partial,
  };
}

export const GEAR = {
  debuffer: gear({
    sets: "Speed plus Perception until accuracy is capped, then Relentless if you can afford the stats.",
    stats: "Boots Speed. Chest and gloves HP% or DEF%. Banner Accuracy. Crit rate is optional.",
    masteries: "Sniper and Master Hexer from Support. Warmaster from Offense. Defense tree so they live the stun.",
  }),
  poison: gear({
    sets: "Lifesteal plus Speed when the team has no Leech. Otherwise Speed, Perception, or Relentless.",
    stats: "Boots Speed. Chest and gloves HP% or DEF%. Enough HP and DEF to take the stun. Accuracy before crit.",
    masteries: "Warmaster. Use Giant Slayer only if they hit three or more times on most turns.",
  }),
  burn: gear({
    sets: "Speed and Perception, or Relentless. Accuracy and uptime beat raw attack.",
    stats: "Boots Speed. Chest and gloves HP% or DEF% unless they are also your nuker. One reliable burn is enough on Demon Lord — a second burn does not stack on the same target. On Hydra, extra burners still help because each head is its own target.",
    masteries: "Warmaster, Sniper, Master Hexer.",
  }),
  nuker: gear({
    sets: "Savage or Lethal. Merciless or Cruel if that is the pair you can finish. Ignore defense is the multiplier.",
    stats: "100% crit rate, then crit damage. Boots Speed unless a tune says otherwise. Chest ATK% on attack champions. Banner Accuracy only if they must land a debuff.",
    masteries: "Helmsmasher if you are not already in an ignore-defense set, otherwise Flawless Execution. Warmaster or Giant Slayer by how many hits they throw.",
    blessing: "Crushing Rend on the main nuker. Leave Brimstone on a support so the nuker can take the damage blessing.",
  }),
  nukerDef: gear({
    sets: "Savage or Lethal, with Perception mixed in if accuracy is short. Relentless is a proven alternative on Gnut.",
    stats: "100% crit rate, high crit damage, and DEF% on chest and gloves — the hit scales off defense. Boots Speed. Accuracy high enough to land Decrease DEF and Weaken.",
    masteries: "Warmaster or Giant Slayer to match the hit count. Helmsmasher if the sets are not already ignoring defense.",
    blessing: "Crushing Rend. He does not need Brimstone if anyone else carries it.",
  }),
  protector: gear({
    sets: "Guardian or Bolster on the ally-protect champion. Speed, Immortal, or Regeneration if you cannot finish a Guardian set.",
    stats: "This champion eats damage for two people. Stack DEF and HP. Boots Speed, matched to the tune so the protect is up before the boss AoE.",
    masteries: "Defense tree, Warmaster, and the mastery that boosts ally protection if you have it. Survival over damage.",
  }),
  support: gear({
    sets: "Speed plus Immortal, Regeneration, or Perception. Relentless on champions whose best skill has a long cooldown.",
    stats: "Boots Speed — supports usually move first. Chest and gloves HP% or DEF%. Resist is a luxury until speed and accuracy are done.",
    masteries: "Support tree: Sniper, Master Hexer, and the healing or turn-meter masteries that match the kit. Warmaster if they still hit the boss.",
  }),
  unkillable: gear({
    sets: "Three Speed sets is the usual answer. The set bonuses are only there to hit a speed number.",
    stats: "Exact speed matters more than any other stat. A classic Maneater and Painkeeper tune is Maneater at 254, Painkeeper at 240, damage dealers at 177–179, and the slow stun target at 121–128. Write the speeds down before you regear. Missing by 2 ruins the comp.",
    acc: "The unkillable champion often needs little accuracy. Debuffers inside the same tune still need 250 on Ultra-Nightmare.",
    masteries: "Take speed masteries. Skip anything that boosts turn meter unless that exact tune calls for it — a surprise turn meter fill desyncs the comp.",
    blessing: "Phantom Touch or Brimstone on the damage dealers. The unkillable champions themselves can hold Cruelty.",
  }),
  shield: gear({
    sets: "Speed plus Immortal, or Bolster if the shield needs to start bigger. Do not dump all your speed to chase a shield set.",
    stats: "Wixwell-style comps want him among the fastest so Increase DEF and Shield are up, then the shield value grows. Chest DEF% or HP%. Accuracy if they also provoke.",
    masteries: "Support and Defense. Lore of Steel if Speed or Perception is equipped. Lasting Gifts helps the buffs stick.",
    blessing: "Cruelty on the buffer. The damage dealer beside them takes Crushing Rend or Brimstone, not both.",
  }),
};
