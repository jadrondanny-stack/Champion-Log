import { createFileRoute } from "@tanstack/react-router";
import { AshenApp } from "@/components/ashen-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AshenApp />;
}
