import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Flame,
  KeyRound,
  ListOrdered,
  Plus,
  Search,
  Shield,
  Skull,
  Swords,
  Trash2,
  Waves,
  X,
} from "lucide-react";
import type { Affinity, BossId, Champion, Rarity, Role } from "@/data/champions";
import { searchChampions } from "@/data/champions";
import { TAG_GROUPS, tagLabel } from "@/data/tags";
import {
  BOSS_META,
  affinityWord,
  bossScore,
  buildHydraKeys,
  buildTeam,
  rankRoster,
  type BossAffinity,
  type Owned,
  type TeamPlan,
} from "@/lib/optimizer";
import { resolveOwned, useRoster } from "@/lib/roster-store";

type Tab = "vault" | "teams" | "ranks";
type RankKey = "overall" | BossId;

const AFFINITIES: Affinity[] = ["Magic", "Force", "Spirit", "Void"];
const RARITY_OPTIONS: Rarity[] = ["Mythical", "Legendary", "Epic", "Rare"];
const ROLES: Role[] = ["Attack", "Defense", "HP", "Support"];

function affinityClass(affinity: Affinity): string {
  if (affinity === "Magic") return "bg-magic";
  if (affinity === "Force") return "bg-force";
  if (affinity === "Spirit") return "bg-spirit";
  return "bg-void";
}

function affinityText(affinity: Affinity): string {
  if (affinity === "Magic") return "text-magic";
  if (affinity === "Force") return "text-force";
  if (affinity === "Spirit") return "text-spirit";
  return "text-void";
}

export function AshenApp() {
  const [tab, setTab] = useState<Tab>("vault");
  const entries = useRoster((s) => s.entries);
  const customs = useRoster((s) => s.customs);
  const affinity = useRoster((s) => s.affinity);

  useEffect(() => {
    void useRoster.persist.rehydrate();
  }, []);

  const owned = useMemo(() => resolveOwned(entries, customs), [entries, customs]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="border-b border-border bg-surface">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-4">
          <span className="flex size-11 items-center justify-center rounded-md bg-raised text-primary">
            <KeyRound className="size-5" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-widest text-gold uppercase">War room</p>
            <h1 className="font-display text-2xl leading-none text-fg">Ashen Keys</h1>
          </div>
          <p className="ml-auto text-right text-sm text-muted tabular-nums">
            {owned.length}
            <span className="block text-xs">in vault</span>
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-5 pb-nav">
        {tab === "vault" ? <Vault owned={owned} /> : null}
        {tab === "teams" ? <Teams owned={owned} affinity={affinity} /> : null}
        {tab === "ranks" ? <Ranks owned={owned} /> : null}
      </main>

      <nav className="nav-safe fixed inset-x-0 bottom-0 border-t border-border bg-surface" aria-label="Sections">
        <div className="mx-auto grid max-w-3xl grid-cols-3">
          <NavButton active={tab === "vault"} onClick={() => setTab("vault")} label="Vault" icon={<Shield className="size-5" />} />
          <NavButton active={tab === "teams"} onClick={() => setTab("teams")} label="Teams" icon={<Swords className="size-5" />} />
          <NavButton active={tab === "ranks"} onClick={() => setTab("ranks")} label="Rank" icon={<ListOrdered className="size-5" />} />
        </div>
      </nav>
    </div>
  );
}

function NavButton({
  active,
  onClick,
  label,
  icon,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  icon: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium ${active ? "text-primary" : "text-muted"}`}
    >
      {icon}
      {label}
    </button>
  );
}

function Vault({ owned }: { owned: Owned[] }) {
  const [query, setQuery] = useState("");
  const [customOpen, setCustomOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const addCatalog = useRoster((s) => s.addCatalog);
  const loadSample = useRoster((s) => s.loadSample);
  const clear = useRoster((s) => s.clear);
  const results = searchChampions(query);
  const counts = new Map<string, number>();
  for (const row of owned) counts.set(row.champ.id, (counts.get(row.champ.id) ?? 0) + 1);

  return (
    <div className="flex flex-col gap-5">
      <p className="text-sm text-muted">
        Add the champions you actually own. Teams take five for Demon Lord and Chimera, six for Hydra. Duplicates are allowed — two Maneaters is a real tune.
      </p>

      <div className="relative">
        <label className="sr-only" htmlFor="champ-search">
          Search champions
        </label>
        <Search className="pointer-events-none absolute top-3.5 left-3 size-5 text-faint" aria-hidden="true" />
        <input
          id="champ-search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search Gnut, Uugo, Geomancer…"
          autoComplete="off"
          className="h-12 w-full rounded-md border border-border bg-surface pr-12 pl-11 text-base text-fg placeholder:text-faint"
        />
        {query ? (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => setQuery("")}
            className="absolute top-1 right-1 flex size-10 items-center justify-center text-muted"
          >
            <X className="size-4" />
          </button>
        ) : null}
        {results.length > 0 ? (
          <ul className="absolute z-10 mt-2 max-h-80 w-full overflow-auto rounded-md border border-border bg-surface">
            {results.map((champ) => {
              const ownedCount = counts.get(champ.id) ?? 0;
              return (
                <li key={champ.id} className="border-b border-border last:border-b-0">
                  <button
                    type="button"
                    onClick={() => {
                      addCatalog(champ.id);
                      setQuery("");
                    }}
                    className="flex min-h-14 w-full items-center gap-3 px-3 py-2 text-left"
                  >
                    <span className={`size-3 shrink-0 rounded-full ${affinityClass(champ.affinity)}`} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium">{champ.name}</span>
                      <span className="block text-xs text-muted">
                        {champ.rarity} · {champ.role} · {champ.affinity}
                      </span>
                    </span>
                    <span className="text-xs text-gold">{ownedCount > 0 ? `Add another (${ownedCount})` : "Add"}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        ) : null}
        {query && results.length === 0 ? (
          <p className="mt-2 text-sm text-muted">Nothing under that name. Add them as a custom champion and tick the roles they actually bring.</p>
        ) : null}
      </div>

      <button
        type="button"
        onClick={() => setCustomOpen((open) => !open)}
        className="flex h-11 items-center gap-2 self-start text-sm font-medium text-gold"
      >
        <Plus className="size-4" />
        {customOpen ? "Close custom champion" : "Champion not in the list"}
      </button>

      {customOpen ? <CustomForm onDone={() => setCustomOpen(false)} /> : null}

      <section className="flex flex-col gap-3">
        <div className="flex items-end justify-between gap-3">
          <h2 className="font-display text-xl">Your vault</h2>
          <div className="flex gap-2">
            <button type="button" onClick={loadSample} className="h-11 rounded-md px-3 text-sm text-gold">
              {owned.length === 0 ? "Load a sample vault" : "Add sample"}
            </button>
            {owned.length > 0 ? (
              <button
                type="button"
                onClick={() => {
                  if (!confirmClear) {
                    setConfirmClear(true);
                    return;
                  }
                  clear();
                  setConfirmClear(false);
                }}
                className="h-11 rounded-md px-3 text-sm text-muted"
              >
                {confirmClear ? "Confirm clear" : "Clear"}
              </button>
            ) : null}
          </div>
        </div>

        {owned.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border bg-surface px-4 py-8 text-center">
            <p className="font-display text-lg">The vault is empty.</p>
            <p className="mt-2 text-sm text-muted">Search a champion above, or load a sample clan-boss vault to see how the teams come out.</p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {owned.map((row) => (
              <VaultRow key={row.uid} row={row} />
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function VaultRow({ row }: { row: Owned }) {
  const remove = useRoster((s) => s.remove);
  const setSpeed = useRoster((s) => s.setSpeed);
  const [open, setOpen] = useState(false);
  return (
    <li className="overflow-hidden rounded-lg border border-border bg-surface">
      <div className="flex">
        <span className={`w-1.5 shrink-0 ${affinityClass(row.champ.affinity)}`} />
        <div className="min-w-0 flex-1 p-3">
          <div className="flex items-start gap-2">
            <button type="button" onClick={() => setOpen((value) => !value)} className="min-w-0 flex-1 text-left">
              <span className="block truncate font-medium">{row.champ.name}</span>
              <span className="mt-0.5 block text-xs text-muted">
                {row.champ.rarity} · {row.champ.role} · {row.champ.faction}
              </span>
            </button>
            <button type="button" onClick={() => remove(row.uid)} aria-label={`Remove ${row.champ.name}`} className="flex size-11 items-center justify-center text-muted">
              <Trash2 className="size-4" />
            </button>
          </div>
          <ScoreTrio champ={row.champ} />
          {open ? <GearBlock champ={row.champ} speed={row.speed} onSpeed={(speed) => setSpeed(row.uid, speed)} /> : null}
          <button type="button" onClick={() => setOpen((value) => !value)} className="mt-2 text-xs font-medium text-gold">
            {open ? "Hide gear" : "Gear and speed"}
          </button>
        </div>
      </div>
    </li>
  );
}

function ScoreTrio({ champ }: { champ: Champion }) {
  return (
    <dl className="mt-2 grid grid-cols-3 gap-2 text-xs">
      <Score label="Demon" value={champ.scores.demon} />
      <Score label="Hydra" value={champ.scores.hydra} />
      <Score label="Chimera" value={champ.scores.chimera} />
    </dl>
  );
}

function Score({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <dt className="text-faint">{label}</dt>
      <dd className="mt-1 h-1.5 overflow-hidden rounded-full bg-raised">
        <span className="block h-full rounded-full bg-primary" style={{ width: `${value}%` }} />
      </dd>
      <dd className="mt-1 tabular-nums text-muted">{value}</dd>
    </div>
  );
}

function GearBlock({
  champ,
  speed,
  onSpeed,
}: {
  champ: Champion;
  speed: number | null;
  onSpeed: (speed: number | null) => void;
}) {
  return (
    <div className="mt-3 flex flex-col gap-3 border-t border-border pt-3 text-sm">
      <p className="text-muted">{champ.blurb}</p>
      <label className="flex items-center justify-between gap-3">
        <span className="text-muted">Speed</span>
        <input
          inputMode="numeric"
          value={speed ?? ""}
          placeholder="—"
          onChange={(event) => {
            const raw = event.target.value.replace(/[^\d]/g, "");
            if (!raw) {
              onSpeed(null);
              return;
            }
            onSpeed(Math.min(400, Number(raw)));
          }}
          className="h-11 w-24 rounded-md border border-border bg-bg px-3 text-right tabular-nums"
        />
      </label>
      <GearLines gear={champ.gear} />
    </div>
  );
}

function GearLines({ gear, compact = false }: { gear: Champion["gear"]; compact?: boolean }) {
  const rows = [
    ["Sets", gear.sets],
    ["Stats", gear.stats],
    ["Accuracy", gear.acc],
    ["Masteries", gear.masteries],
    ["Blessing", gear.blessing],
  ] as const;
  const visible = compact ? rows.slice(0, 2) : rows;
  const extra = compact ? rows.slice(2) : [];
  return (
    <div className="flex flex-col gap-3">
      <dl className="flex flex-col gap-3">
        {visible.map(([label, value]) => (
          <div key={label}>
            <dt className="text-xs font-medium tracking-wide text-gold uppercase">{label}</dt>
            <dd className="mt-1 text-sm text-fg">{value}</dd>
          </div>
        ))}
      </dl>
      {extra.length > 0 ? (
        <details>
          <summary className="cursor-pointer text-sm font-medium text-gold">Accuracy, masteries, blessing</summary>
          <dl className="mt-3 flex flex-col gap-3">
            {extra.map(([label, value]) => (
              <div key={label}>
                <dt className="text-xs font-medium tracking-wide text-gold uppercase">{label}</dt>
                <dd className="mt-1 text-sm text-fg">{value}</dd>
              </div>
            ))}
          </dl>
        </details>
      ) : null}
    </div>
  );
}

function CustomForm({ onDone }: { onDone: () => void }) {
  const addCustom = useRoster((s) => s.addCustom);
  const [name, setName] = useState("");
  const [rarity, setRarity] = useState<Rarity>("Legendary");
  const [affinity, setAffinity] = useState<Affinity>("Void");
  const [role, setRole] = useState<Role>("Support");
  const [tags, setTags] = useState<string[]>([]);

  function toggle(tag: string) {
    setTags((current) => (current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag]));
  }

  return (
    <form
      className="flex flex-col gap-4 rounded-lg border border-border bg-surface p-4"
      onSubmit={(event) => {
        event.preventDefault();
        if (!name.trim() || tags.length === 0) return;
        addCustom({ name, affinity, rarity, role, tags });
        onDone();
      }}
    >
      <h2 className="font-display text-lg">Custom champion</h2>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-muted">Name</span>
        <input
          value={name}
          onChange={(event) => setName(event.target.value)}
          maxLength={40}
          className="h-12 rounded-md border border-border bg-bg px-3"
        />
      </label>
      <ChipPick label="Rarity" value={rarity} options={RARITY_OPTIONS} onChange={setRarity} />
      <ChipPick label="Affinity" value={affinity} options={AFFINITIES} onChange={setAffinity} />
      <ChipPick label="Type" value={role} options={ROLES} onChange={setRole} />
      {TAG_GROUPS.map((group) => (
        <fieldset key={group.title}>
          <legend className="mb-2 text-sm text-muted">{group.title}</legend>
          <div className="flex flex-wrap gap-2">
            {group.tags.map((tag) => {
              const on = tags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  aria-pressed={on}
                  onClick={() => toggle(tag)}
                  className={`h-11 rounded-full border px-3 text-sm ${on ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`}
                >
                  {tagLabel(tag)}
                </button>
              );
            })}
          </div>
        </fieldset>
      ))}
      <button
        type="submit"
        disabled={!name.trim() || tags.length === 0}
        className="h-12 rounded-md bg-primary font-medium text-primary-fg disabled:opacity-40"
      >
        Add to vault
      </button>
      {tags.length === 0 ? <p className="text-xs text-faint">Tick at least one role so the team builder knows what they do.</p> : null}
    </form>
  );
}

function ChipPick<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: readonly T[];
  onChange: (value: T) => void;
}) {
  return (
    <fieldset>
      <legend className="mb-2 text-sm text-muted">{label}</legend>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            aria-pressed={value === option}
            onClick={() => onChange(option)}
            className={`h-11 rounded-full border px-3 text-sm ${value === option ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`}
          >
            {option}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function Teams({
  owned,
  affinity,
}: {
  owned: Owned[];
  affinity: Record<BossId, BossAffinity>;
}) {
  const [boss, setBoss] = useState<BossId>("demon");
  const [hydraKey, setHydraKey] = useState(0);
  const setAffinity = useRoster((s) => s.setAffinity);
  const plan = useMemo(
    () => (boss === "hydra" ? null : buildTeam(owned, boss, affinity[boss])),
    [owned, boss, affinity],
  );
  const hydra = useMemo(() => (boss === "hydra" ? buildHydraKeys(owned, affinity.hydra) : []), [owned, boss, affinity.hydra]);
  const active = boss === "hydra" ? (hydra[hydraKey] ?? null) : plan;
  const meta = BOSS_META[boss];

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-3 gap-2" role="tablist" aria-label="Boss">
        <BossTab active={boss === "demon"} onClick={() => setBoss("demon")} label="Demon Lord" icon={<Skull className="size-4" />} />
        <BossTab active={boss === "hydra"} onClick={() => setBoss("hydra")} label="Hydra" icon={<Waves className="size-4" />} />
        <BossTab active={boss === "chimera"} onClick={() => setBoss("chimera")} label="Chimera" icon={<Flame className="size-4" />} />
      </div>

      <p className="text-sm text-muted">{meta.keys}</p>

      <fieldset>
        <legend className="mb-2 text-sm text-muted">{boss === "hydra" ? "Head affinity to focus" : "Boss affinity today"}</legend>
        <div className="flex flex-wrap gap-2">
          {(boss === "hydra" ? (["Any", ...AFFINITIES] as BossAffinity[]) : AFFINITIES).map((option) => (
            <button
              key={option}
              type="button"
              aria-pressed={affinity[boss] === option}
              onClick={() => setAffinity(boss, option)}
              className={`h-11 rounded-full border px-3 text-sm ${affinity[boss] === option ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`}
            >
              {option === "Any" ? "Mixed heads" : option}
            </button>
          ))}
        </div>
      </fieldset>

      {owned.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border bg-surface px-4 py-8 text-center">
          <p className="font-display text-lg">Add champions first.</p>
          <p className="mt-2 text-sm text-muted">The vault is empty, so there is no team to forge.</p>
        </div>
      ) : null}

      {boss === "hydra" && hydra.length > 0 ? (
        <div className="grid grid-cols-3 gap-2">
          {hydra.map((keyPlan, index) => (
            <button
              key={index}
              type="button"
              aria-pressed={hydraKey === index}
              onClick={() => setHydraKey(index)}
              className={`h-11 rounded-md border text-sm ${hydraKey === index ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`}
            >
              Key {index + 1}
              <span className="block text-xs opacity-80">{keyPlan.members.length}/6</span>
            </button>
          ))}
        </div>
      ) : null}

      {active ? <TeamView plan={active} expected={meta.size} speedsKnown={active.turnOrder.every((m) => (m.speed ?? 0) > 0)} /> : null}

      <details className="rounded-lg border border-border bg-surface p-4">
        <summary className="cursor-pointer font-medium">Stat targets</summary>
        <ul className="mt-3 flex list-disc flex-col gap-2 pl-5 text-sm text-muted">
          {meta.targets.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      </details>
    </div>
  );
}

function BossTab({
  active,
  onClick,
  label,
  icon,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  icon: ReactNode;
}) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={`flex h-14 flex-col items-center justify-center gap-1 rounded-md border text-xs font-medium ${active ? "border-primary bg-raised text-fg" : "border-border text-muted"}`}
    >
      {icon}
      {label}
    </button>
  );
}

function TeamView({ plan, expected, speedsKnown }: { plan: TeamPlan; expected: number; speedsKnown: boolean }) {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-xs font-medium tracking-wide text-gold uppercase">{plan.archetype}</p>
        <h2 className="font-display text-2xl">
          Best to worst
          <span className="text-muted"> · {plan.members.length} of {expected}</span>
        </h2>
        <p className="mt-2 text-sm text-muted">{plan.note}</p>
        {plan.runnerUp ? <p className="mt-2 text-sm text-gold">{plan.runnerUp.note}</p> : null}
      </div>

      <ul className="flex flex-wrap gap-2">
        {plan.coverage.map((item) => (
          <li
            key={item.id}
            className={`rounded-full border px-3 py-1 text-xs ${item.met ? "border-primary text-primary" : "border-border text-faint"}`}
          >
            {item.met ? "Ready" : "Missing"} · {item.label}
          </li>
        ))}
      </ul>

      {plan.warnings.length > 0 ? (
        <ul className="flex flex-col gap-2 rounded-lg border border-border bg-raised p-3 text-sm">
          {plan.warnings.map((warning) => (
            <li key={warning}>{warning}</li>
          ))}
        </ul>
      ) : null}

      <ol className="flex flex-col gap-3">
        {plan.members.map((member, index) => (
          <li key={member.owned.uid} className="overflow-hidden rounded-lg border border-border bg-surface">
            <div className="flex">
              <span className={`w-1.5 shrink-0 ${affinityClass(member.owned.champ.affinity)}`} />
              <div className="min-w-0 flex-1 p-4">
                <div className="flex items-baseline justify-between gap-3">
                  <p className="text-xs text-faint">#{index + 1}</p>
                  <p className={`text-xs ${affinityText(member.owned.champ.affinity)}`}>
                    {member.owned.champ.affinity}
                    {member.weak ? " · weak hit" : ""}
                  </p>
                </div>
                <h3 className="font-display text-xl leading-tight">{member.owned.champ.name}</h3>
                <p className="mt-1 text-sm text-muted">
                  {member.owned.champ.rarity} · {member.owned.champ.role}
                  {member.owned.speed ? ` · ${member.owned.speed} speed` : ""}
                </p>
                <p className="mt-2 text-sm">{member.why}</p>
                <p className="mt-1 text-xs text-faint">{member.owned.champ.blurb}</p>
                <div className="mt-3">
                  <GearLines gear={member.owned.champ.gear} compact />
                </div>
              </div>
            </div>
          </li>
        ))}
      </ol>

      <section>
        <h3 className="font-display text-lg">{speedsKnown ? "Turn order by your speeds" : "Suggested open"}</h3>
        <p className="mt-1 text-sm text-muted">
          {speedsKnown
            ? "Fastest first. Ties of 1 speed can flip on the in-game roll."
            : "A role order, not a tune. Add speeds on each champion in the vault and this becomes a real turn order. Unkillable comps ignore this and follow the published speeds."}
        </p>
        <ol className="mt-3 flex flex-col gap-2">
          {plan.turnOrder.map((member, index) => (
            <li key={member.uid} className="flex items-center gap-3 text-sm">
              <span className="flex size-8 items-center justify-center rounded-full bg-raised text-xs tabular-nums text-gold">{index + 1}</span>
              <span className="min-w-0 flex-1 truncate">{member.champ.name}</span>
              <span className="text-xs text-muted tabular-nums">{member.speed ? member.speed : tagHint(member.champ)}</span>
            </li>
          ))}
        </ol>
      </section>

      {plan.suggestions.length > 0 ? (
        <section>
          <h3 className="font-display text-lg">Worth building next</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {plan.suggestions.map((row) => (
              <li key={row.champ.id} className="rounded-md border border-border px-3 py-3 text-sm">
                <span className="font-medium">{row.champ.name}</span>
                <span className="text-muted"> · {row.champ.rarity} · {row.reason}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}

function tagHint(champ: Champion): string {
  if (champ.tags.includes("speed-aura") || champ.tags.includes("tm-boost")) return "Lead";
  if (champ.tags.includes("unkillable") || champ.tags.includes("block-damage")) return "Tune";
  if (champ.tags.includes("dec-atk") || champ.tags.includes("ally-protect")) return "Early";
  if (champ.tags.includes("dec-def") || champ.tags.includes("weaken")) return "Debuff";
  return "Damage";
}

function Ranks({ owned }: { owned: Owned[] }) {
  const [key, setKey] = useState<RankKey>("overall");
  const [rarity, setRarity] = useState<Rarity | "All">("All");
  const ranked = rankRoster(owned, key).filter((row) => rarity === "All" || row.champ.rarity === rarity);

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-2xl">Best to worst</h2>
        <p className="mt-1 text-sm text-muted">
          Overall is an even split of Demon Lord, Hydra, and Chimera. A specialist can rank lower overall and still be the right pick on one boss.
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        {(["overall", "demon", "hydra", "chimera"] as const).map((option) => (
          <button
            key={option}
            type="button"
            aria-pressed={key === option}
            onClick={() => setKey(option)}
            className={`h-11 rounded-full border px-3 text-sm ${key === option ? "border-primary bg-primary text-primary-fg" : "border-border text-muted"}`}
          >
            {option === "overall" ? "Overall" : option === "demon" ? "Demon Lord" : option === "hydra" ? "Hydra" : "Chimera"}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {(["All", ...RARITY_OPTIONS] as const).map((option) => (
          <button
            key={option}
            type="button"
            aria-pressed={rarity === option}
            onClick={() => setRarity(option)}
            className={`h-11 rounded-full border px-3 text-sm ${rarity === option ? "border-gold text-gold" : "border-border text-muted"}`}
          >
            {option === "All" ? "All rarities" : option}
          </button>
        ))}
      </div>
      {ranked.length === 0 ? (
        <p className="rounded-lg border border-dashed border-border px-4 py-8 text-center text-sm text-muted">Nothing in the vault for this filter.</p>
      ) : (
        <ol className="flex flex-col gap-2">
          {ranked.map((row, index) => {
            const score = bossScore(row.champ, key);
            return (
              <li key={row.uid} className="rounded-lg border border-border bg-surface p-3">
                <div className="flex items-baseline gap-3">
                  <span className="w-6 text-sm text-gold tabular-nums">{index + 1}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{row.champ.name}</p>
                    <p className="text-xs text-muted">
                      {row.champ.rarity} · {row.champ.affinity} · {row.champ.role}
                    </p>
                  </div>
                  <span className="text-lg tabular-nums text-fg">{score}</span>
                </div>
                <div className="mt-2 ml-9 h-1.5 overflow-hidden rounded-full bg-raised">
                  <span className="block h-full rounded-full bg-primary" style={{ width: `${score}%` }} />
                </div>
                <p className="mt-2 ml-9 text-xs text-muted">{row.champ.gear.sets}</p>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
