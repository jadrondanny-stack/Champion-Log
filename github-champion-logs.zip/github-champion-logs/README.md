# Champion Logs

Unofficial Raid: Shadow Legends barracks tracker and Hydra / boss team helper.

**Live site after you turn Pages on:**  
`https://YOUR_GITHUB_USERNAME.github.io/REPO_NAME/`

## Publish on GitHub Pages

1. On GitHub, click **New repository**.
2. Name it something like `champion-logs`. Leave it **Public**. Do not add a README (these files already have one).
3. Click **uploading an existing file**.
4. Drag **every file in this folder** into the box (`index.html`, `manifest.webmanifest`, `sw.js`, `favicon.svg`, `README.md`).
5. Click **Commit changes**.
6. Open the repo → **Settings** → **Pages**.
7. Under **Build and deployment**:
   - Source: **Deploy from a branch**
   - Branch: **main** (or **master**)
   - Folder: **/ (root)**
8. Click **Save**.
9. Wait 1–2 minutes. Refresh this Pages settings page. GitHub will show the public URL.

Open that URL on your phone → Share → Add to Home Screen.

## Files
- `index.html` — the app
- `manifest.webmanifest` + `sw.js` — install / offline
- `favicon.svg` — icon

Barracks data is stored in the visitor’s browser. Use Export CSV to back it up.
