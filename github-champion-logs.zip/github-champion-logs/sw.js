self.addEventListener("install", event => {
  event.waitUntil(caches.open("cl-v3").then(c => c.addAll([
    "./",
    "./index.html",
    "./manifest.webmanifest",
    "./favicon.svg"
  ])));
  self.skipWaiting();
});
self.addEventListener("activate", event => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(hit => hit || fetch(event.request).then(res => {
      const copy = res.clone();
      caches.open("cl-v3").then(c => c.put(event.request, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match("./index.html")))
  );
});
